//_______Библиотека js-функций ______________
$(function(){
	version = "1.00"
	$('#version').html('v '+version)
	xD = getDate('now'); $("#xD input").val(xD); d1_forms = xD
	xYear = xD.substr(-4); aD = '01.01.'+xYear; $("#aD input").val(aD); d0_forms = '01.'+xD.substr(-7);
	$("[name=datepicker]").datepicker()
	Spr = []; nameRef = 'chairs'; ref0()
	xP = {'id_chair':23,'chair':'ИС','grup':'','nbook':0,'student':'','years':'2022-2023','p_chr':0,
		'id_teacher':0,'teacher':'','id_subject':0,'subject':'','curs':1,'semestr':1,'stavka':1}
	xV = {'N':'','d':'','h_unit':'','typefos':'Экзамен','id_teacher':0,'teacher':'','tch':'','dek':''}
	Ri = zz = 0 
	rep0 = {'grup':'','id_subject':0,'subject':'','semestr':1,'I':0,'A':1,'B':'','id_chair':0,'competentions':'',
		    'lections':0,'labworks':0,'practics':0,'indepworks':0,'control':0,'cw':0,'cp':0,
			'together':'','typefos':'Экзамен','id_teacher':0,'id_teacherA':0,'id_lab':0,'stavka':'','stavkaA':'','d':'','N':0,'tch':0,'dek':0}
	Rep = []; Rep[0] = rep0
	prmA = false
	Chr = []; Chr[0] = {'grup':'','id_subject':0,'subject':'','semestr':1,'lections':0,'labworks':0,'practics':0,'control':0,
		'cw':0,'cp':0,'together':'','typefos':'Экзамен','id_teacher':0,'teacher':'','id_teacherA':0,'teachA':'','id_lab':0,'stavka':'','stavkaA':''}
	Dek = []; Dek[0] = {'grup':'','id_subject':0,'subject':'','curs':1,'semestr':1,'h_unit':'','typefos':'Экзамен','id_teacher':0,'teacher':'','d':'','N':''}
	id_user = ''; USER = {'login':"",'pass':"",'pass_new':"",'username':"",'phone':"",'email':"",'note':""}
	$('#article,#accountB,#adminB').hide()
	$('#enter').show()
	sec = 'forms'
	setPaint()
	$('body').keydown(function(e){
		switch (e.which){
			case 13: 
			if ($('#enter').css('display') == 'block' && $('#c-login').css('display') == 'block'){
				USER.login = $('.login input').val()
				USER.pass = $('.pass input').val()
				Login()
			}
			break
			case 27: 
				tf = false;  
				$('#true').hide() 
				$('.sels').remove();
				if (sec == 'ref'){ref_= {}; $('#c-ref0').hide(); break} 
			break
			case 38: 
				if (sec == 'plan' && Ri > 0){--Ri; if (Ri < (Chr.length - zN)) ++zz; screenChr0()}
				break
			case 40: 
				if (sec == 'plan' && Ri < Chr.length-1){++Ri; if (zz > 0) --zz; screenChr0()}
				break
			default: return; break
		}
	})
})

function readChr(){           // Чтение данных индивидуального плана из БД (таблица Chr[i])
	$.ajax({type:"POST", async:false, url:"dep.php", data:{func:"readChr",xD,xP}, dataType:"JSON",
		success: function(a){Chr = a; sortChr(xP.id_teacher); Ri = zz = 0; screenChr0()}, 
		error:function(a){alertOn(a['responseText'],'!')}
	})
}
function writeChr(){          // Запись данных индивидуального плана в БД (таблица Chr[i])
	$.ajax({type:"POST", async:false, url:"dep.php", data:{func:"writeChr",Chr}, dataType:"JSON",
		success: function(a){alertOn('Данные индивидуальных планов в базу данных внесены!')},
		error:function(a){alertOn(a['responseText'],'!')}
	})
}
function switchPchr(){        // Переключение режима распределенной нагрузки
	if (xP.p_chr == 0 && xP.id_teacher == 0){
		xP.p_chr = 1
		$('#p_chr').css('color','rgba(14,72,116,0.8)')
		$('#p_chr').html('<i class="fa fa-toggle-on"></i>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; с распределенными')
	} else {
		xP.p_chr = 0
		$('#p_chr').css('color','rgba(14,72,116,0.4)')
		$('#p_chr').html('<i class="fa fa-toggle-off"></i>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; без распределенных')
	}
	prmA = false
	$('#chrA').hide()
	section()
}
function screenChr0(){        // Вывод на экран таблицы Chr[i]
	prmA = false
	$('#chrA').hide()
	tf = true
	if (xP.id_teacher > 0 && xP.stavka != '') zN = 16; else zN = Chr.length 
	if (zN > Chr.length) zN = Chr.length
	x = Chr.length-zN-zz; if (x < 0) x = 0
	if (x > Ri){x = Ri; zz = Chr.length-zN+Ri}
	var tab = 
		'<div name="0">'+
			'<div class="cell r0 c0">Группа</div>'+
			'<div class="cell r0 c1">Дисциплина</div>'+
			'<div class="cell r0 c2">сем</div>'+
	        '<div class="cell r0 c3">лек</div>'+
	        '<div class="cell r0 c4">лаб</div>'+
			'<div class="cell r0 c5">пр</div>'+
	        '<div class="cell r0 c6">к/р</div>'+
	        '<div class="cell r0 c7">к/п</div>'+
			'<div class="cell r0 c8">Экзамен/Зачет</div>'+
			'<div class="cell r0 c9">Преподаватель</div>'+
			'<div class="cell r0 c10">ст.</div>'+
		'</div>'
	for (i=0; i<zN; i++){
		tab +=
		'<div name="'+(i+1)+'">'+
			'<div class="cell r'+(i+1)+' c0"></div>'+
			'<div class="cell r'+(i+1)+' c1"></div>'+
			'<div class="cell r'+(i+1)+' c2"></div>'+
			'<div class="cell r'+(i+1)+' c3"></div>'+
			'<div class="cell r'+(i+1)+' c4"></div>'+
			'<div class="cell r'+(i+1)+' c5"></div>'+
			'<div class="cell r'+(i+1)+' c6"></div>'+
			'<div class="cell r'+(i+1)+' c7"></div>'+
			'<div class="cell r'+(i+1)+' c8"></div>'+
			'<div class="cell r'+(i+1)+' c9 select" type="DB" php="searchTeacher" func="setTeacher('+(i+x)+',val)" width_="520"></div>'+
			'<div class="cell r'+(i+1)+' c10 select" ref="Stavka" func="setStavka('+(i+x)+',val)"></div>'+
			'<div class="c-plus"><i class="fa fa-font"></i></div>'+
		'</div>'
	}
	$("#chr").html(tab)
	selPicker("#chr")
	screenChr()
	$('#chr .c0,#chr .c1,#chr .c2,#chr .c3,#chr .c4,#chr .c5,#chr .c6,#chr .c7,#chr .c8,#chr .c9,#chr .c10').click(function(){
		if ($(this).parent().attr('name') > 0){
			prmA = false; $('#chrA').hide(); 
			Ri = $(this).parent().attr('name')-1+x;
			screenChrColor()
		}
	})
	$('#chr .c3,#chr .c4,#chr .c5,#chr .c6,#chr .c7,#chr .c8').click(function(){
		prmA = false
		i_teach = $(this).parent().attr('name') - 1
		var j = +$(this).attr('class').slice(-1)-3
debugger
		set_0_5(i_teach,j)
	})
	$('#chr .c-plus').click(function(){
		if (prmA){prmA = false; $('#chrA').hide(); return}
		prmA = true
		Ri = $(this).parent().attr('name')-1+x
		i_teach = $(this).parent().attr('name') - 1
		var offset = $(this).offset()
		$('#chrA').css('top',(Math.round(offset.top)-5)+'px')
		tab = '<div name="'+(i_teach+1)+'">'+
				'<div class="cell c0"></div>'+
				'<div class="cell c1"></div>'+
				'<div class="cell c2"></div>'+
				'<div class="cell c3"></div>'+
				'<div class="cell c4"></div>'+
				'<div class="cell c5"></div>'+
				'<div class="cell c6"></div>'+
				'<div class="cell c7"></div>'+
				'<div class="cell c8"></div>'+
				'<div class="cell c9 select" type="DB" php="searchTeacher" func="setTeacher('+(i_teach+x)+',val)" width_="520"></div>'+
				'<div class="cell c10 select" ref="Stavka" func="setStavka('+(i_teach+x)+',val)"></div>'+
				'<div class="c-plus"><i class="fa fa-font"></i></div>'+
			  '</div>'
		$("#chrA").html(tab).show()
		selPicker("#chrA")
		screenChrColor()
		screenChrA()
		$("#chrA .fa-font").css('color','rgb(0,155,39)')
		$("#chrA .c-plus").click(function(){prmA = false; $('#chrA').hide()})
		$('#chrA .c3,#chrA .c4,#chrA .c5,#chrA .c6,#chrA .c7,#chrA .c8').click(function(){
			i_teach = $(this).parent().attr('name') - 1
			var j = +$(this).attr('class').slice(-1)-3
			set_0_5(i_teach,j)
		})
	})
}
function screenChrColor(){    // Вывод на экран параметров отображения Chr
	xGrup = Chr[Ri].grup;
	$('.fa-file-excel-o').css('color','rgba(14,72,116,0.2)')
	$('#chr input,#chr .cell').css('background-color','rgb(243,250,254)')
	for (var i=0; i<zN; i++) if (Chr[i+x].grup == xGrup) $('#chr [name='+(i+1)+'] input,#chr [name='+(i+1)+'] .cell').css('background-color','white')
	$('#chr [name=0] .cell').css('background-color','rgb(243,243,243)')
	if (prmA) $('#chrA input,#chrA .cell').css('background-color','rgb(235,255,235)');
		else $('#chr [name='+(Ri-x+1)+'] input,#chr [name='+(Ri-x+1)+'] .cell').css('background-color','rgb(255,255,235)')
}
function set_0_5(i,j){        // Изменение параметра "нагрузка" в таблице Chr[i]
	if (Chr[i].id_teacher > 0){
		var x = 0
		switch (j){
			case 0: x = Chr[i].lections; break
			case 1: x = Chr[i].labworks; break
			case 2: x = Chr[i].practics; break
			case 3: x = Chr[i].cw; break
			case 4: x = Chr[i].cp; break
			case 5: x = 1; break
		}	
		if (x > 0){
			var s = Chr[i].s_teacher, sA = Chr[i].s_teacherA
			if (prmA) var c = sA[j]; else var c = s[j]; 
			if (c == '0') c = '1'; else if (c == '1') c = '2'; else c = '0'
			if (prmA){
				if (s[j] == '0') Chr[i].s_teacherA = sA.substr(0,j)+c+sA.substr(j+1)
			} else {
				Chr[i].s_teacher = s.substr(0,j)+c+s.substr(j+1)
				if (c != '0') Chr[i].s_teacherA = sA.substr(0,j)+'0'+sA.substr(j+1)
			}					
		}
		if (prmA) screenChrA(); else screenChr()
	}	
}
function setTeacher(i,val){   // Изменение параметра "Преподаватель" в таблице Chr[i]
	val = val.replace(/ {1,}/g," ")
	var a = val.split(' (')
	if (prmA) Chr[i].teacherA = a[0]; else Chr[i].teacher = a[0]
	if (a[1]){
		a = a[1].split(')'); 
		if (prmA) Chr[i].id_teacherA = +a[0]; else Chr[i].id_teacher = +a[0]
	} else {
		if (prmA){Chr[i].id_teacherA = 0; Chr[i].s_teacherA = '000000'; Chr[i].stavkaA = ''}
			else {Chr[i].id_teacher = 0; Chr[i].s_teacher = '000000'; Chr[i].stavka = ''; Chr[i].id_teacherA = 0; Chr[i].s_teacherA = '000000'; Chr[i].stavkaA = ''}
	}	
	if (prmA) screenChrA(); else screenChr()
}
function setStavka(i,val){    // Изменение параметра "Ставка преподавателя" в таблице Chr[i]
	if (val == '-') val = ''
	if (prmA) Chr[i].stavkaA = val; else Chr[i].stavka = val
	if (prmA) screenChrA(); else screenChr()
}
function screenChrA(){        // Вывод на экран элементов таблицы chrA
	$("#chrA .c0").html(Chr[i_teach].grup)
	$("#chrA .c1").html(Chr[i_teach].subject)
	$("#chrA .c2").html(Chr[i_teach].semestr)
	if (Chr[i_teach].id_teacherA == 0){Chr[i_teach].s_teacherA = '000000'; Chr[i_teach].stavkaA = ''}
	if (Chr[i_teach].id_teacherA > 0) var c = Chr[i_teach].s_teacherA; else var c = ''
	s_teachA(c,3); $("#chrA .c3").html(u_(Chr[i_teach].lections,0))
	s_teachA(c,4); $("#chrA .c4").html(u_(Chr[i_teach].labworks,0))
	s_teachA(c,5); $("#chrA .c5").html(u_(Chr[i_teach].practics,0))
	s_teachA(c,6); var s = ''; if (Chr[i_teach].cw > 0) s = 'да'; $("#chrA .c6").html(s)
	s_teachA(c,7); var s = ''; if (Chr[i_teach].cp > 0) s = 'да'; $("#chrA .c7").html(s)
	s_teachA(c,8); $("#chrA .c8").html(Chr[i_teach].typefos)
	$("#chrA .c9 input").val(Chr[i_teach].teacherA)
	$("#chrA .c10 input").val(Chr[i_teach].stavkaA)
}
function s_teach(i,s,j){      // Стиль нагрузки chr
	if (s == '') $("#chr .r"+(i+1)+".c"+j).css('color','rgba(14,72,116,0.75)').css('font-style','normal'); else
		if (s[j-3] == '0') $("#chr .r"+(i+1)+".c"+j).css('color','red').css('font-style','normal'); else
			if (s[j-3] == '1') $("#chr .r"+(i+1)+".c"+j).css('color','rgb(14,72,116)').css('font-style','normal'); else
				$("#chr .r"+(i+1)+".c"+j).css('color','rgb(166,166,166)').css('font-style','italic')
}
function s_teachA(s,j){       // Стиль нагрузки chrA
	if (s == '') $("#chrA .c"+j).css('color','rgba(14,72,116,0.75)').css('font-style','normal'); else
		if (s[j-3] == '0') $("#chrA .c"+j).css('color','red').css('font-style','normal'); else
			if (s[j-3] == '1') $("#chrA .c"+j).css('color','rgb(14,72,116)').css('font-style','normal'); else
				$("#chrA .c"+j).css('color','rgb(166,166,166)').css('font-style','italic')
}
function screenChr(){         // Вывод на экран элементов таблицы Chr
	screenChrColor()
	for (i=0; i<zN; i++){
		$("#chr .r"+(i+1)+".c0").html(Chr[i+x].grup)
		$("#chr .r"+(i+1)+".c1").html(Chr[i+x].subject)
		$("#chr .r"+(i+1)+".c2").html(Chr[i+x].semestr)
		if (Chr[i+x].id_teacher == 0){Chr[i+x].s_teacher = '000000'; Chr[i+x].stavka = ''}
		if (Chr[i+x].id_teacher > 0) var c = Chr[i+x].s_teacher; else var c = ''
		s_teach(i,c,3); $("#chr .r"+(i+1)+".c3").html(u_(Chr[i+x].lections,0))
		s_teach(i,c,4); $("#chr .r"+(i+1)+".c4").html(u_(Chr[i+x].labworks,0))
		s_teach(i,c,5); $("#chr .r"+(i+1)+".c5").html(u_(Chr[i+x].practics,0))
		s_teach(i,c,6); var s = ''; if (Chr[i+x].cw > 0) s = 'да'; $("#chr .r"+(i+1)+".c6").html(s)
		s_teach(i,c,7); var s = ''; if (Chr[i+x].cp > 0) s = 'да'; $("#chr .r"+(i+1)+".c7").html(s)
		s_teach(i,c,8); $("#chr .r"+(i+1)+".c8").html(Chr[i+x].typefos)
		$("#chr .r"+(i+1)+".c9 input").val(Chr[i+x].teacher)
		$("#chr .r"+(i+1)+".c10 input").val(Chr[i+x].stavka)
		var tf = false 
		for (var k=0; k<6; k++){
			var m = 0
			switch (k){
				case 0: m = Chr[i+x].lections; break
				case 1: m = Chr[i+x].labworks; break
				case 2: m = Chr[i+x].practics; break
				case 3: m = Chr[i+x].cw; break
				case 4: m = Chr[i+x].cp; break
				case 5: m = 1; break
			}	
			if (m > 0 && Chr[i+x].s_teacher[k] == '0') tf = true
		}
		if (tf) $("#chr [name="+(i+1)+"] .c-plus").show(); else $("#chr [name="+(i+1)+"] .c-plus").hide()
	}
	if (xP.id_teacher > 0 && xP.stavka != '') screenChr_()
}
function screenChr_(){        // Вывод на экран итоговых значений элементов таблицы Chr
	var s = {'s01':0,'s02':0,'s03':0,'s04':0,'s05':0,'s06':0,'s11':0,'s12':0,'s13':0,'s14':0,'s15':0,'s16':0}
	for (i=0; i<Chr.length; i++){if ((Chr[i].id_teacher == xP.id_teacher && Chr[i].stavka == xP.stavka)||(Chr[i].id_teacherA == xP.id_teacher && Chr[i].stavkaA == xP.stavka)){ 
		j = Chr[i].semestr % 2 === 0 ? "1" : "0"
		var tf = true,id_subject = Chr[i].id_subject,id_teacher = Chr[i].id_teacher,x = Chr[i].s_teacher
		if (Chr[i].id_teacherA == id_teacher && Chr[i].stavkaA == xP.stavka) x = Chr[i].s_teacherA 
		arr = ['94','95','96','97','98','141','143']
		if (arr.indexOf(id_subject) > -1){
			s['s'+j+'3'] += 2*(Chr[i].N1+Chr[i].N2)
		} else {
			if (x[0] == '1') s['s'+j+'1'] += +Chr[i].lections
			if (x[1] == '1') s['s'+j+'2'] += +Chr[i].labworks*Chr[i].N0
			if (x[2] == '1') s['s'+j+'3'] += +Chr[i].practics*Chr[i].N0
			if (Chr[i].cp > 0 && x[3] == '1') s['s'+j+'5'] += 3.5*(Chr[i].N1+Chr[i].N2)
			if (Chr[i].cw > 0 && x[4] == '1') s['s'+j+'5'] += 2.5*(Chr[i].N1+Chr[i].N2)
			if (Chr[i].typefos == 'Экзамен' && x[5] == '1')	s['s'+j+'6'] += 1 + 0.25*(Chr[i].N1+Chr[i].N2)
		}		
	}}
	var tab = 
		'<div name="0">'+
			'<div class="cell r0 c0">Семестр</div>'+
	        '<div class="cell r0 c1">всего</div>'+
	        '<div class="cell r0 c2">лек</div>'+
	        '<div class="cell r0 c3">лаб</div>'+
			'<div class="cell r0 c4">пр</div>'+
	        '<div class="cell r0 c6">к/п</div>'+
	        '<div class="cell r0 c7">зкз</div>'+
		'</div>'
		tab +=
		'<div name="1">'+
			'<div class="cell r1 c0">Осенний</div>'+
	        '<div class="cell r1 c1">'+u_(s.s01+s.s02+s.s03+s.s05+s.s06,2)+'</div>'+
	        '<div class="cell r1 c2">'+u_(s.s01,0)+'</div>'+
	        '<div class="cell r1 c3">'+u_(s.s02,0)+'</div>'+
			'<div class="cell r1 c4">'+u_(s.s03,0)+'</div>'+
	        '<div class="cell r1 c6">'+u_(s.s05,2)+'</div>'+
	        '<div class="cell r1 c7">'+u_(s.s06,2)+'</div>'+
		'</div>'
		tab +=
		'<div name="2">'+
			'<div class="cell r2 c0">Весенний</div>'+
	        '<div class="cell r2 c1">'+u_(s.s11+s.s12+s.s13+s.s15+s.s16,2)+'</div>'+
	        '<div class="cell r2 c2">'+u_(s.s11,0)+'</div>'+
	        '<div class="cell r2 c3">'+u_(s.s12,0)+'</div>'+
			'<div class="cell r2 c4">'+u_(s.s13,0)+'</div>'+
	        '<div class="cell r2 c6">'+u_(s.s15,2)+'</div>'+
	        '<div class="cell r2 c7">'+u_(s.s16,2)+'</div>'+
		'</div>'
		tab +=
		'<div name="3">'+
			'<div class="cell r3 c0">И т о г о</div>'+
	        '<div class="cell r3 c1">'+u_(s.s01+s.s02+s.s03+s.s05+s.s06+s.s11+s.s12+s.s13+s.s15+s.s16,2)+'</div>'+
	        '<div class="cell r3 c2">'+u_(s.s01+s.s11,0)+'</div>'+
	        '<div class="cell r3 c3">'+u_(s.s02+s.s12,0)+'</div>'+
			'<div class="cell r3 c4">'+u_(s.s03+s.s13,0)+'</div>'+
			'<div class="cell r3 c6">'+u_(s.s05+s.s15,2)+'</div>'+
	        '<div class="cell r3 c7">'+u_(s.s06+s.s16,2)+'</div>'+
		'</div>'
	$("#chr_").html(tab)
}
function readDek(){           // Чтение данных деканата из БД (таблица Dek[i])
	$.ajax({type:"POST", async:false, url:"dep.php", data:{func:"readDek",xD,xP}, dataType:"JSON",
		success: function(a){Dek = a; screenDek0()},
		error:function(a){alertOn(a['responseText'],'!')}
	})
}
function writeDek(){          // Запись данных деканата в БД (таблица Dek[i])
	$.ajax({type:"POST", async:false, url:"dep.php", data:{func:"writeDek",Dek}, dataType:"JSON",
		success: function(a){alertOn('Даты, номера ведомостей экзаменов и зачетов в базу данных внесены!')},
		error:function(a){alertOn(a['responseText'],'!')}
	})
}
function screenDek0(){        // Вывод на экран структуры таблицы Dek[i]
	var tab = 
		'<div name="0">'+
			'<div class="cell r0 c0">Группа</div>'+
			'<div class="cell r0 c1">Дисциплина</div>'+
			'<div class="cell r0 c2">курс</div>'+
			'<div class="cell r0 c3">сем</div>'+
	        '<div class="cell r0 c4">объем</div>'+
	        '<div class="cell r0 c5">Экзамен/Зачёт</div>'+
			'<div class="cell r0 c6">Преподаватель</div>'+
	        '<div class="cell r0 c7">дата</div>'+
	        '<div class="cell r0 c8">№</div>'+
		'</div>'
	for (i=0; i<Dek.length; i++){
		tab +=
		'<div name="'+(i+1)+'">'+
			'<div class="cell r'+(i+1)+' c0"></div>'+
			'<div class="cell r'+(i+1)+' c1"></div>'+
			'<div class="cell r'+(i+1)+' c2"></div>'+
			'<div class="cell r'+(i+1)+' c3"></div>'+
			'<div class="cell r'+(i+1)+' c4"></div>'+
			'<div class="cell r'+(i+1)+' c5"></div>'+
			'<div class="cell r'+(i+1)+' c6"></div>'+
			'<div class="cell r'+(i+1)+' c7"><input name="datepicker" onchange="Dek['+i+'].d=d_($(this).val())"></div>'+
			'<div class="cell r'+(i+1)+' c8"><input onchange="Dek['+i+'].N=$(this).val()"></div>'+
		'</div>'
	}
	$("#dek").html(tab)
	$("#dek [name=datepicker]").datepicker()
	screenDek()
}
function screenDek(){         // Вывод на экран элементов таблицы Dek[i]
	for (i=0; i<Dek.length; i++){
		$("#dek .r"+(i+1)+".c0").html(Dek[i].grup)
		$("#dek .r"+(i+1)+".c1").html(Dek[i].subject)
		$("#dek .r"+(i+1)+".c2").html(Dek[i].curs)
		$("#dek .r"+(i+1)+".c3").html(Dek[i].semestr)
		$("#dek .r"+(i+1)+".c4").html(Dek[i].h_unit)
		$("#dek .r"+(i+1)+".c5").html(Dek[i].typefos)
		$("#dek .r"+(i+1)+".c6").html(Dek[i].teacher)
		s = Dek[i].d; if (s == '01.01.2000') s = ''
		$("#dek .r"+(i+1)+".c7 input").val(s)
		$("#dek .r"+(i+1)+".c8 input").val(u_(Dek[i].N,0)).mask("9?99",{placeholder:""})
	}
}
function readRep(){           // Чтение данных учебного плана из БД (таблица Rep[i])
	if (xP.grup == ''){alertOn('Необходимо задать учебную группу!'); return}
	$.ajax({type:"POST", async:false, url:"dep.php", data:{func:"readRep",xP}, dataType:"JSON",
		success: function(a){Rep = a; screenRep0()},
		error:function(a){alertOn(a['responseText'],'!')}
	})
}
function writeRep(){          // Запись данных учебного плана в БД (таблица Rep[i])
	I = 0; s = '';
	for (j=0; j<Rep.length; j++){
		if (s != Rep[j].id_subject) ++I
		s = Rep[j].id_subject
		Rep[j].I = I
	}
	$.ajax({type:"POST", async:false, url:"dep.php", data:{func:"writeRep",xP,Rep}, dataType:"JSON",
		success: function(a){alertOn('Учебный план группы <b>'+xP.grup+'</b> сохранен в базе данных!')},
		error:function(a){alertOn(a['responseText'],'!')}
	})
}
function setSubject(i,val){   // Изменение параметра "дисциплина" в таблице Rep[i]
	val = val.replace(/ {1,}/g," ")
	var a = val.split(' (')
	Rep[i].subject = a[0]
	a = a[1].split(')');
	Rep[i].id_subject = +a[0]
	$("#rep .r"+(i+1)+".c2 input").val(Rep[i].subject)
}
function setChair(i,val){     // Изменение параметра "код кафедры" в таблице Rep[i]
	val = val.replace(/ {1,}/g," ")
	var a = val.split(' ')
	s = a[0]; a = val.split('код '); var id = +a[1]
	Rep[i].id_chair = id
	$("#rep .r"+(i+1)+".c11 input").val(id)
}
function screenRep0(){        // Вывод на экран структуры таблицы Rep[i]
	$('#catalog-N').html(xP.grup)
	rep0.grup = xP.grup
	var tab = 
		'<div name="0">'+
			'<div class="cell r0 c0">+</div>'+
			'<div class="cell r0 c1">Индекс</div>'+
			'<div class="cell r0 c2">Дисциплина</div>'+
			'<div class="cell r0 c3">сем</div>'+
	        '<div class="cell r0 c4">лек</div>'+
	        '<div class="cell r0 c5">лаб</div>'+
			'<div class="cell r0 c6">пр</div>'+
	        '<div class="cell r0 c7">с/р</div>'+
	        '<div class="cell r0 c8">К</div>'+
	        '<div class="cell r0 c9">к/р</div>'+
	        '<div class="cell r0 c10">к/п</div>'+
			'<div class="cell r0 c11">Экзамен/Зачет</div>'+
	        '<div class="cell r0 c12">каф</div>'+
	        '<div class="cell r0 c13">Компетенции</div>'+
			'<div class="c-plus"><i class="fa fa-plus-circle"></i></div>'+
		'</div>'
	for (i=0; i<Rep.length; i++){
		tab +=
		'<div name="'+(i+1)+'">'+
			'<div class="cell r'+(i+1)+' c0" onclick="switchA('+i+')"></div>'+
			'<div class="cell r'+(i+1)+' c1"><input onchange="Rep['+i+'].B=$(this).val()"></div>'+
			'<div class="cell r'+(i+1)+' c2 select" type="DB" php="searchSubject" func="setSubject('+i+',val)" width_="600"></div>'+
			'<div class="cell r'+(i+1)+' c3"><input onchange="Rep['+i+'].semestr=$(this).val()"></div>'+
			'<div class="cell r'+(i+1)+' c4"><input onchange="Rep['+i+'].lections=$(this).val()"></div>'+
			'<div class="cell r'+(i+1)+' c5"><input onchange="Rep['+i+'].labworks=$(this).val()"></div>'+
			'<div class="cell r'+(i+1)+' c6"><input onchange="Rep['+i+'].practics=$(this).val()"></div>'+
			'<div class="cell r'+(i+1)+' c7"><input onchange="Rep['+i+'].indepworks=$(this).val()"></div>'+
			'<div class="cell r'+(i+1)+' c8"><input onchange="Rep['+i+'].control=$(this).val()"></div>'+
			'<div class="cell r'+(i+1)+' c9" onclick="switchCw('+i+')"></div>'+
			'<div class="cell r'+(i+1)+' c10" onclick="switchCp('+i+')"></div>'+
			'<div class="cell r'+(i+1)+' c11 select" ref="TypeFos" func="Rep['+i+'].typefos=val"></div>'+
			'<div class="cell r'+(i+1)+' c12 select" type="DB" php="searchChair" func="setChair('+i+',val)" width_="500"></div>'+
			'<div class="cell r'+(i+1)+' c13"><input onchange="Rep['+i+'].competentions=$(this).val()"></div>'+
			'<div class="c-plus"><i class="fa fa-plus-circle"></i><i class="fa fa-minus-circle"></i></div>'+
		'</div>'
	}
	$("#rep").html(tab)
	selPicker("#rep")
	screenRep()
	$('#rep .fa-plus-circle').click(function(){
		var i = $(this).parent().parent().attr('name');
		if (i == 0) Rep.splice(Rep.length,0,rep0); else {
			Rep.splice(i-1,0,rep0)
			if (Rep[i]){
				Rep[i-1].A = Rep[i].A; Rep[i-1].B = Rep[i].B; Rep[i-1].id_subject = Rep[i].id_subject;  Rep[i-1].subject = Rep[i].subject; Rep[i-1].semestr = Rep[i].semestr;
				Rep[i-1].lections = Rep[i].lections; Rep[i-1].labworks = Rep[i].labworks; Rep[i-1].practics = Rep[i].practics; Rep[i-1].indepworks = Rep[i].indepworks;
				Rep[i-1].control = Rep[i].control; Rep[i-1].cw = Rep[i].cw; Rep[i-1].cp = Rep[i].cp;
				Rep[i-1].typefos = Rep[i].typefos; Rep[i-1].id_chair = Rep[i].id_chair; Rep[i-1].competentions = Rep[i].competentions; 
			}
		}	
		screenRep0()
	})
	$('#rep .fa-minus-circle').click(function(){
		var i = $(this).parent().parent().attr('name');
 		if (i == 0){rep = []; Rep[0] = rep0} else {Rep.splice(i-1,1); if (Rep.length == 0) Rep[0] = rep0}
		screenRep0()
	})
}
function screenRep(){         // Вывод на экран элементов таблицы Rep[i]
	for (i=0; i<Rep.length; i++){
		s = '-'; if (Rep[i].A > 0) s = '+'
		$("#rep .r"+(i+1)+".c0").html(s)
		$("#rep .r"+(i+1)+".c1 input").val(Rep[i].B)
		$("#rep .r"+(i+1)+".c2 input").val(Rep[i].subject)
		$("#rep .r"+(i+1)+".c3 input").val(Rep[i].semestr).mask("9?9",{placeholder:""})
		$("#rep .r"+(i+1)+".c4 input").val(u_(Rep[i].lections,0)).mask("9?9",{placeholder:""})
		$("#rep .r"+(i+1)+".c5 input").val(u_(Rep[i].labworks,0)).mask("9?9",{placeholder:""})
		$("#rep .r"+(i+1)+".c6 input").val(u_(Rep[i].practics,0)).mask("9?99",{placeholder:""})
		$("#rep .r"+(i+1)+".c7 input").val(u_(Rep[i].indepworks,0)).mask("9?99",{placeholder:""})
		$("#rep .r"+(i+1)+".c8 input").val(u_(Rep[i].control,0)).mask("9?99",{placeholder:""})
		var s = ''; if (Rep[i].cw > 0) s = 'да'; $("#rep .r"+(i+1)+".c9").html(s)
		var s = ''; if (Rep[i].cp > 0) s = 'да'; $("#rep .r"+(i+1)+".c10").html(s)
		$("#rep .r"+(i+1)+".c11 input").val(Rep[i].typefos)
		s = ''; if (Rep[i].id_chair > 0) s = Rep[i].id_chair
		$("#rep .r"+(i+1)+".c12 input").val(s)
		$("#rep .r"+(i+1)+".c13 input").val(Rep[i].competentions)
	}
}
function readSheet(){         // Чтение данных ведомости Sheet[i] из БД
	if (xP.grup == ''){alertOn('Необходимо задать учебную группу!'); return}
	if (xP.id_subject == 0){alertOn('Необходимо задать дисциплину!'); return}
	$.ajax({type:"POST", async:false, url:"dep.php", data:{func:"readSheetV",xP}, dataType:"JSON",
		success: function(a){
			xV = a;
			if (xV.d == '*'){alertOn('В учебном плане группы <b>'+xP.grup+'</b> дисциплина <b>"'+xP.subject+'"</b> не предусмотрена!'); Sheet0(); return}
			if (xV.d == '**'){alertOn('В учебном плане группы <b>'+xP.grup+'</b> дисциплина <b>"'+xP.subject+'"</b> в <b>'+xP.semestr+'-ом</b> семестре не предусмотрена!'); Sheet0(); return}
			if (xV.d == ''){alertOn('Зачетно-экзаменационная ведомость группы <b>'+xP.grup+'</b> дисциплина <b>"'+xP.subject+'"</b> в <b>'+xP.semestr+'-ом</b> семестре еще не открыта Деканатом!'); Sheet0(); return}
			$.ajax({type:"POST", async:false, url:"dep.php", data:{func:"readSheet",xP}, dataType:"JSON",
				success: function(a){Sheet = a; screenSheet0()},
				error:function(a){alertOn(a['responseText'],'!')}
			})
		},
		error:function(a){alertOn(a['responseText'],'!')}
	})
}
function writeSheet(){        // Запись данных ведомости Sheet[i] в БД
	$.ajax({type:"POST", async:false, url:"dep.php", data:{func:"writeSheet",xP,xV,Sheet}, dataType:"JSON",
		success: function(a){
			if (a == '-') alertOn('Зачетно-экзаменационная ведомость группы <b>'+xP.grup+'</b> дисциплина <b>"'+xP.subject+'"</b> в <b>'+xP.semestr+'-ом</b> не предусмотрена!');
				else alertOn('Зачетно-экзаменационная ведомость группы <b>'+xP.grup+'</b> дисциплина <b>"'+xP.subject+'"</b> в <b>'+xP.semestr+'-ом</b> сохранена в базе данных!')
		},
		error:function(a){alertOn(a['responseText'],'!')}
	})
}
function Sheet0(){            // Формирование начальных параметров зачетной ведомости xS,Sheet[i]
	xV = {'N':'','d':'','h_unit':'','typefos':'Экзамен','teacher':''}
	Sheet = []
	screenSheet0()
}
function screenSheet0(){      // Вывод на экран формы таблицы зачетной ведомости Sheet[i]
	$('#sheet-N').html(xV.N)
	$('#sheet-G1').html('Группа: '+xP.grup)
	$('#sheet-G2').html('Курс: '+xP.curs)
	$('#sheet-G3').html('Семестр: '+xP.semestr)
	$('#sheet-S').html(xP.subject)
	$('#sheet-H').html(xV.h_unit)
	$('#sheet-A').html(xV.typefos)
	if (xV.typefos == 'Зачёт') Spr['Est'] = ['зачтено','не зачтено','н/я']; else Spr['Est'] = ['отлично','хорошо','удовлетворительно','не удовлетворительно','н/я'] 

	$('#sheet-T').html(xV.teacher)
	$('#sheet-D').html(xV.d)
	var tab = 
		'<div name="0">'+
			'<div class="cell r0 c0">п/п</div>'+
			'<div class="cell r0 c1">Фамилия, имя, отчество студента</div>'+
			'<div class="cell r0 c2">Шифр зачетной книжки</div>'+
			'<div class="cell r0 c3">Оценка / зачтено (прописью)</div>'+
	        '<div class="cell r0 c4">Подпись преподавателя</div>'+
		'</div>'
	for (i=0; i<Sheet.length; i++){
		tab +=
		'<div name="'+(i+1)+'">'+
			'<div class="cell r'+(i+1)+' c0"></div>'+
			'<div class="cell r'+(i+1)+' c1"></div>'+
			'<div class="cell r'+(i+1)+' c2"></div>'
			if (xV.tch > 0 || Sheet[i].est == 'не допущен') tab +='<div class="cell r'+(i+1)+' c3">'+Sheet[i].est+'</div>'; else
				tab +='<div class="cell r'+(i+1)+' c3 select" ref="Est" func="Sheet['+i+'].est=val;screenSheet()"></div>'
			tab +='<div class="cell r'+(i+1)+' c4"></div>'+
		'</div>'
	}
	$("#sheet").html(tab)
	selPicker("#sheet")
	screenSheet()
}
function screenSheet(){       // Вывод на экран данных таблицы зачетной ведомости Sheet[i]
	var est = []; for (i=0; i<6; i++) est[i] = 0
	for (i=0; i<Sheet.length; i++){
		$("#sheet .r"+(i+1)+".c0").html(i+1)
		$("#sheet .r"+(i+1)+".c1").html(Sheet[i].student)
		$("#sheet .r"+(i+1)+".c2").html(Sheet[i].nbook)
		$("#sheet .r"+(i+1)+".c3 input").val(Sheet[i].est)
		switch (Sheet[i].est){
			case 'зачтено': ++est[5]; break
			case 'отлично': ++est[5]; break
			case 'хорошо': ++est[4]; break
			case 'удовлетворительно': ++est[3]; break
			case 'не зачтено': ++est[2]; break
			case 'не удовлетворительно': ++est[2]; break
			case 'н/я': ++est[1]; break
			case 'не допущен': ++est[0]; break
		}
	}
	$('#est_sum').html(Sheet.length)
	if (est[5] > 0) s = est[5]; else s = '-'; $('#est_5').html(s)
	if (est[4] > 0) s = est[4]; else s = '-'; $('#est_4').html(s)
	if (est[3] > 0) s = est[3]; else s = '-'; $('#est_3').html(s)
	if (est[2] > 0) s = est[2]; else s = '-'; $('#est_2').html(s)
	if (est[1] > 0) s = est[1]; else s = '-'; $('#est_1').html(s)
	if (est[0] > 0) s = est[0]; else s = '-'; $('#est_0').html(s)
	var s = ''; if (xV.tch > 0) s = 'закрыта преподавателем'; $('#tch').html(s)
	    s = ''; if (xV.dek > 0) s = 'закрыта деканом'; $('#dekan').html(s)
}

function Login(){             // Вход в ИС
	$.ajax({type:"POST", async:false, url:"user.php", data:{func:"Login",USER}, dataType:"JSON",
		success: function(a){
			USER = a
			$('#enter').hide()
			if (USER.access.slice(0,1) != '1' && USER.access.slice(0,1) != '5'){
				alertOn('Этот аккаунт не предназначен для ИС Кафедра !','!')
				$('#article').hide();
			} else {
				id_user = USER.id_user
				$('#article').show()
				$('#user').html('('+USER.access+') '+USER.username).show()
				Spr['Semestr'] = ['1','2','3','4','5','6','7','8'] 
				Spr['TypeFos'] = ['Экзамен','Зачёт','Зачёт с оценкой','нет'] 
				Spr['Years'] = ['2022-2023','2021-2022','2020-2021','2019-2020'] 
				Spr['Stavka'] = ['-','1','1/2','0,75','0,5','0,25','час'] 
				Spr['Together'] = ['-','лек','лаб','пр','экз','все'] 
				Spr['OFO'] = ['ОФО','ЗФО','ОЗФО'] 
				Spr['Level'] = ['Специалитет','Бакалавриат','Магистратура','Аспирантура'] 
				Spr['subTeach'] = ['лабораторные','практические','лаб+практические','лаб+экзамен','все кроме лек'] 
				frmList = {
					'f11':'таб.№1.1 "Зачетная ведомость"',
					'f12':'таб.№1.2 "Индивидуальный план"',
					'f13':'таб.№1.3 "Учебный план"',
					'f14':'таб.№1.4 "Расчет нагрузки"',
					'f15':'таб.№1.5 "Расчет штатов"',
					'f21':'таб.№2.1 "Список кафедр"',
					'f22':'таб.№2.2 "Список групп"',
					'f23':'таб.№2.3 "Список студентов"',
					'f24':'таб.№2.4 "Список преподавателей"',
					'f25':'таб.№2.5 "Список дисциплин"',
					'f26':'таб.№2.6 "Зачётная книжка студента"'
				}	
				$('#header').show()
				section()
			}	
		},
		error:function(a){alertOn(a['responseText'],'!')
			$('#accountB,#adminB').hide()
			$('#pass_btn').show()
		}
	})
}
function section_color(s){    // Отображение цвета секции
	$('.section').css('background-color','rgb(243,250,254)')
	$('.menu div').css('background-color','rgba(14,72,116,0.3)').css('color','rgb(255,255,255)')
    $('.menu .fa-pencil-square-o').css('color','rgba(14,72,116,0.8)')
    $('.menu .fa-edit').css('color','rgba(14,72,116,0.8)')
	$('#'+s+'B').css('background-color','rgb(255,255,255)').css('color','rgb(14,72,116)')
}
function section(){           // Отображение секции основных блоков
	section_color(sec)
	$('#chair input').val(xP.chair)
	$('#grup input').val(xP.grup)
	$('#student input').val(xP.student)
	$('#years input').val(xP.years)
	$('#teacher input').val(xP.teacher)
	$('#subject input').val(xP.subject)
	$('#semestr input').val(xP.semestr)
	$('#stavka input').val(xP.stavka)
	$('#chair,#p_chr,#grup,#student,#years,#teacher,#subject,#semestr,#stavka').hide()
	switch (sec){
		case 'sbook': $('#student').show(); break
		case 'sheet': $('#grup,#subject,#semestr').show(); readSheet(); break
		case 'dek': $('#chair,#grup,#years,#teacher,#subject').show(); readDek(); break
		case 'plan': $('#chair,#p_chr,#grup,#years,#teacher,#subject,#stavka').show(); readChr(); break
		case 'catalog': $('#grup').show(); readRep(); break
		case 'ref': nameRef = ''; ref0(); break
		case 'forms': $('#chair,#grup,#student,#years,#teacher,#subject,#semestr,#stavka').show(); screenForms(); break
	}	
	$('.section').hide() 
	$('#c-'+sec).show() 
}

function searchChair(){       // Обработка результата поиска и выбора параметров кафедры
	val = val.replace(/ {1,}/g," ")
	var a = val.split(' ')
	xP.chair = a[0]
	a = val.split('код ');
	xP.id_chair = 0; if (a[1]) xP.id_chair = +a[1]
	section()
}
function searchGrup(){        // Обработка результата поиска и выбора параметров группы
	val = val.replace(/ {1,}/g," ")
	var a = val.split(' кафедра ')
	xP.grup = a[0];
	xP.curs = xD.substr(-2)-a[0].substr(0,2)
	var m = +xD.substr(3,2)
	if (m < 8) xP.semestr = 2*xP.curs; else  {++xP.curs; xP.semestr = 2*xP.curs-1}
	xP.nbook = 0; xP.student = '';
	section()
}
function searchStudent(){     // Обработка результата поиска и выбора параметров студента
	val = val.replace(/ {1,}/g," "); var a = val.split('№')
	if (a[1] != xP.nbook){
		xP.id_chair = 0; xP.chair = '';
		xP.nbook = a[1];
		a = val.split(' группа '); xP.student = a[0]
		a = a[1].split(','); xP.grup = a[0]
		$.ajax({type:'POST',async:false,url:'dep.php',data:{func:'readChair',grup:xP.grup},dataType:'JSON',
			success: function(a){xP.id_chair = a.id_chair; xP.chair = a.chair; section()}, 
			error: function(a){alertOn(a['responseText'],'!')}
		})
	}	
}
function searchTeacher(){     // Обработка результата поиска и выбора параметров преподавателя
	val = val.replace(/ {1,}/g," ")
	var a = val.split(' (')
	xP.teacher = a[0]
	if (a[1]){a = a[1].split(')'); xP.id_teacher = +a[0]} else xP.id_teacher = 0
	if (xP.id_teacher > 0 && xP.p_chr == 1) switchPchr()
	section()
}
function searchSubject(){     // Обработка результата поиска и выбора параметров дисциплины
	val = val.replace(/ {1,}/g," ")
	var a = val.split(' (')
	xP.subject = a[0]
	if (a[1]){a = a[1].split(')'); xP.id_subject = +a[0]} else xP.id_subject = 0
	section()
}
function switchContract(){    // Переключение параметра Contract
	if (ref_.contract != 'бюджет') ref_.contract = 'бюджет'; else ref_.contract = 'внебюджет'; $('#contract').html(ref_.contract)
}
function switchSubgrup(){     // Переключение параметра Subgrup
	if (ref_.subgrup == '1') ref_.subgrup = '2'; else ref_.subgrup = '1'; $('#subgrup').html(ref_.subgrup)
}
function switchSession(){     // Переключение параметра Session
	if (ref_.session == 'есть') ref_.session = 'нет'; else ref_.session = 'есть'; $('#session').html(ref_.session)
}
function switchTch(){         // Переключение параметра Tch
	if (xV.dek == 0){if (xV.tch > 0) xV.tch = 0; else xV.tch = xV.id_teacher}
	var s = ''; if (xV.tch > 0) s = 'закрыта преподавателем'; $('#tch').html(s)
	screenSheet0()	
}
function switchA(i){          // Переключение параметра A
	if (Rep[i].A > 0){Rep[i].A = 0; s = '-'} else {Rep[i].A = 1; s = '+'}
	$("#rep .r"+(i+1)+".c0").html(s)
}
function switchCw(i){         // Переключение параметра cp
	if (Rep[i].cw == 0){Rep[i].cw = 1; s = 'да'} else {Rep[i].cw = 0; s = ''}
	$("#rep .r"+(i+1)+".c9").html(s)
}
function switchCp(i){         // Переключение параметра cp
	if (Rep[i].cp == 0){Rep[i].cp = 1; s = 'да'} else {Rep[i].cp = 0; s = ''}
	$("#rep .r"+(i+1)+".c10").html(s)
}

function true_(s){            // Подтверждение удаления
	$('#true').show() 
	$('#true').html('Введите код для подтвеждения процедуры удаления данных: <input onchange="true_del(\''+s+'\')">')
	$('#true input').focus()
}
function true_del(s){         // Удаление после подтверждения
	var c = $('#true input').val()
	tf = true
	if (c == '2408'){
		if (s == 'Ref') Ref('del',nameRef)
		$('#true').hide()
	}		
}
function alertOn(s,i,y){      // Отображение информационного сообщения
	$('#alert').css('display','block') 
	if (i == '!'){
		$('#alert').css('box-shadow','5px 5px 100px rgb(250,100,50)') 
		i = '<i class="fa fa-warning"></i>'
	} else {
		$('#alert').css('box-shadow','5px 5px 100px rgb(17,103,181)') 
		i = '<i class="fa fa-info-circle"></i>'
	}
	if (y) y += 'px'; else y = '350px'
	$('#alert').css('top',y).html(i+' '+s);
	$('body').off('mousedown.alert')
	$('body').on('mousedown.alert',function(e){
		div = $('#alert')
		if (!div.has(e.target).length){
			$('#alert').css('display','none')
			$('body').off('mousedown.alert')
		}
	})
}
function sectionUser(s){      // Отображение секции блока авторизации
	$('.section').hide();
	$('#c-'+s).show()
    $('.menu div').css('background-color','rgba(14,72,116,0.3)').css('color','rgb(255,255,255)')
	$('#'+s+'B').css('background-color','rgb(255,255,255)').css('color','rgb(14,72,116)')
	switch (s){
		case 'login': 
			$('#c-login .login input').val(USER.login)
			$('#c-login .pass input').val('')
			$('#pass_btn').hide()
		break
		case 'account': 
			$('#article').hide()
			$('#enter,#accountB').show()
			if (USER.id_user=='1'||USER.id_user=='123') $('#adminB').show(); else $('#adminB').hide()
			$('#c-account .login input').val(USER.login)
			$('#c-account .username input').val(USER.username)
			$('#c-account .phone input').val(USER.phone)
			$('#c-account .email input').val(USER.email)  
			$('#c-account .note textarea').val(USER.note)
			$('#c-account .access input').val(cRef(USER.access,'Access'))
			$('#c-account .pass input').val('')
		break
		case 'admin': 
			$('#c-admin .login input').val(USER.login)
			$('#c-admin .username input').val(USER.username)
			$('#c-admin .phone input').val(USER.phone)
			$('#c-admin .email input').val(USER.email)
			$('#c-admin .note textarea').val(USER.note)
			$('#c-admin .access input').val(cRef(USER.access,'Access'))
			$('#c-admin .pass input').val('')
		break
	}
}
function CheckIn(func){       // Регистрация пользователя
	$.ajax({type:"POST", async:false, url:"user.php", data:{func:func,USER}, dataType:"JSON",
		success: function(a){alertOn(a)},
		error: function(a){alertOn(a['responseText'],'!')}
	})
}
function readLogin(){         // Чтение данных пользователя по логину
	$.ajax({type:"POST", async:false, url:"user.php", data:{func:"readLogin",USER}, dataType:"JSON",
		success: function(a){USER = a; sectionUser('admin')},
		error:function(a){alertOn(a['responseText'],'!')}
	})
}
function loginOut(){          // Выход из аккаунта пользователя
	document.cookie = "hash = 0"
	document.cookie = "login = 0"
	USER = {'login':"",'pass':"",'pass_new':"",'username':"",'phone':"",'email':"",'note':""}
	$('#user').html('')
	$('#accountB,#adminB,#article').hide()
	sectionUser('login')
	$('#enter').show()
}
function selPicker(Div){      // Сборка элементов select`а (в т.ч. из справочников)
	if (Div != '') Div += ' '
	$(Div+'.select').html('<input spellcheck="false"><i class="fa fa-pencil-square-o"></i><div class="sel"></div>')
	$('.select .sel').css('background-color',paint.bc1)
	$(Div+'.select[type=DB] input').attr('placeholder','...')
	$('.select input, .select i').click(function(){// Отображение списка по нажатию click
		var id = '#s_e_l'
		$(this).parent().attr('id','s_e_l')
		var val0 = $(this).val(), val00 = val0
		if ($(id+' .sel').css('display') == 'none'){
			function fval(){val = val.replace('<b>',''); val = val.replace('</b>',''); val = val.replace('<i>','');val = val.replace('</i>','')}
			function max_(){// Определение "высоты" блока sel
				max = $(id).attr('max')
				if (max) max = +max; else max = Spr_.length
				if (max > Spr_.length) max = Spr_.length
				if (max > 25) max = 25
				h0 = 0
				h1 = max
			}		
			function screenSel(h0,h1){// Вывод списка на экран
				if (((h1-h0) != Spr_.length)||(type == 'DB')){
					$(id+' input').attr('readonly',false).css('cursor','text')
					$(id+' i').show()
				} // else {$(id+' input').attr('readonly',true).css('cursor','pointer')}
				if (Spr_.length ==0){$(id+' .sel').hide(); return}
				var s = ''
				for (var i=h0; i<h1; i++){
					s += '<div val="'+i+'">'+Spr_[i]
					if (i == h0) s += '<i class="fa fa-sort-asc"></i>'
					if (i == (h1-1)) s += '<i class="fa fa-sort-desc"></i>'
					s += '</div>'
				}
				$(id+' .sel').html(s)
				var w = +$(id+' input').css('width').split('px')[0]+4
				var width_ = $(id).attr('width_')
				if (width_) w = width_
				$(id+' .sel').css('width',w+'px')
				$(id+' .sel').show();
				if (h0 == 0) $(id+' .sel .fa-sort-asc').hide(); else $(id+' .sel .fa-sort-asc').show()
				if (h1 == Spr_.length) $(id+' .sel .fa-sort-desc').hide(); else $(id+' .sel .fa-sort-desc').show()
				$(id+' .sel div').click(function(){// Выбор элемента из списка по нажатию click
					val = $(this).text()
					$(id+' input').val(val); hideSel();	if (func) eval(func)
				})
			}	
			function hideSel(){// Закрытие блока sel
				$(id+' .sel').hide().html(''); $(id+' i').hide()
				$(id+' input').off('keyup').attr('readonly',true).css('cursor','pointer')
				$(id).removeAttr('id');
				$('body').off('mousedown.sel')
			}
			var type = $(id).attr('type')
			var	func = $(id).attr('func')
			var Spr_ = []
			if (type!='DB'){var ref = $(id).attr('ref'); if (Spr[ref]) Spr_ = Spr[ref]}
			var max = h0 = h1 = 0
			max_() 
			screenSel(h0,h1)
			if ((max < Spr_.length)||(type=='DB')) $(id+' input').on('keyup','',function(e){// Управление выпадающим списком
				var tf = false
				switch (e.which){
					case 27:
						val = $(this).val()
						if (val != '') val = val00
						$(id+' input').val(val); hideSel(); if (func) eval(func)
					break
					case 33: if (h0 > 0){h0 = h0-max; h1 = h1-max; if (h0 < 0){h0 = 0; h1 = max} tf = true} break
					case 34: if (h1 < Spr_.length){h0 += max; h1 += max; if (h1 > Spr_.length){h1 = Spr_.length; h0 = h1 - max} tf = true} break
					case 38: if (h0 > 0){h0 = h0-1; h1 = h1-1; tf = true} break
					case 40: if (h1 < Spr_.length){++h0; ++h1; tf = true} break
					default:
						if (e.which == 13 && Spr_.length == 1){
							val = Spr_[0]
							fval();	$(id+' input').val(val); hideSel(); if (func) eval(func)
							break
						}
						val = $(this).val()
						var ch = String.fromCharCode(e.which), tf = /^[а-яА-Яa-zA-Z0-9]/.test(ch)
						if (val00 == val0 && tf){
							for (var i=0; i<val.length; i++){ch = val[i]; if (ch != val0[i]) break}
						    val = ch; $(this).val(val)
						}
						if (val != val0 || e.which == 13){
							val0 = val
							Spr_ = []
							if (type=='DB'){
								var php = $(id).attr('php')
								$.ajax({type:"POST",async:true, url:"dep.php",data:{func:php,s:val,aD,xD},dataType:"JSON",
									beforeSend:function(){$('.fa-pencil-square-o').removeClass('fa-pencil-square-o').addClass('fa-spinner fa-spin').css('color','rgba(14,72,116,0.9)')},
									complete:function(){$('.fa-spinner').removeClass('fa-spinner fa-spin').addClass('fa-pencil-square-o').css('color','rgba(14,72,116,0.3)')},
									success: function(a){Spr_ = a; max_(); screenSel(h0,h1)},
									error:function(a){alertOn(a['responseText'],'!')}
								})
							} else if (Spr[ref]){
								for (var i=0; i<Spr[ref].length; i++) if (Spr[ref][i].indexOf(val) >= 0) Spr_.push(Spr[ref][i])
								max_(); tf = true
							}
						}
						break
				}
				if (tf) screenSel(h0,h1)
			})
		}
		$('body').on('mousedown.sel',function(e){if (!$(id+' .sel').has(e.target).length) hideSel()})
	})
}
function setPaint(){          // Установка палитры цветов на экран
	$.ajax({type:"POST",async:false,url:"user.php",data:{func:"readPaint"}, dataType:"JSON",
		success: function(a){paint = a
			if (paint.bc) $('header,article,footer').css('background-color',paint.bc); else paint.bc = 'rgb(234,244,253)'
			var a = paint.bc.split(')'); a = a[0].split('('); a = a[1].split(',')
			bc_red = a[0].trim(); bc_green = a[1].trim(); bc_blue = a[0].trim();
			$('#bc_red').val(bc_red).mask("9?99",{placeholder:""}); $('#bc_green').val(bc_green).mask("9?99",{placeholder:""}); $('#bc_blue').val(bc_blue).mask("9?99",{placeholder:""});
			if (paint.c) $('header,article,footer').css('color',paint.c); else paint.c = 'rgb(14,72,116)'
			var a = paint.c.split(')'); a = a[0].split('('); a = a[1].split(',')
			c_red = a[0].trim(); c_green = a[1].trim(); c_blue = a[0].trim();
			$('#c_red').val(c_red).mask("9?99",{placeholder:""}); $('#c_green').val(c_green).mask("9?99",{placeholder:""}); $('#c_blue').val(c_blue).mask("9?99",{placeholder:""});
			if (!paint.bc1) paint.bc1 = 'rgb(225,236,236)'
			var a = paint.bc1.split(')'); a = a[0].split('('); a = a[1].split(',')
			bc1_red = a[0].trim(); bc1_green = a[1].trim(); bc1_blue = a[0].trim();
			$('#bc1_red').val(bc1_red).mask("9?99",{placeholder:""}); $('#bc1_green').val(bc1_green).mask("9?99",{placeholder:""}); $('#bc1_blue').val(bc1_blue).mask("9?99",{placeholder:""});
			if (!paint.c1) paint.c1 = 'rgb(7,39,63)'
			var a = paint.c1.split(')'); a = a[0].split('('); a = a[1].split(',')
			c1_red = a[0].trim(); c1_green = a[1].trim(); c1_blue = a[0].trim();
			$('#c1_red').val(c1_red).mask("9?99",{placeholder:""}); $('#c1_green').val(c1_green).mask("9?99",{placeholder:""}); $('#c1_blue').val(c1_blue).mask("9?99",{placeholder:""});
			selPicker('')
			sectionUser('login')
		},
		error:function(a){alertOn(a['responseText'],'!')}
	})
}
function changePaint(){       // Изменение палитры цветов
	if (bc_red > 255) bc_red = 255; if (bc_green > 255) bc_green = 255; if (bc_blue > 255) bc_blue = 255;
	if (c_red > 255) c_red = 255; if (c_green > 255) c_green = 255; if (c_blue > 255) c_blue = 255;
	paint.bc = 'rgb('+bc_red+','+bc_green+','+bc_blue+')'
	paint.c = 'rgb('+c_red+','+c_green+','+c_blue+')'
	$('header,article,footer').css('background-color',paint.bc).css('color',paint.c)
	if (bc1_red > 255) bc1_red = 255; if (bc1_green > 255) bc1_green = 255; if (bc1_blue > 255) bc1_blue = 255;
	if (c1_red > 255) c1_red = 255; if (c1_green > 255) c1_green = 255; if (c1_blue > 255) c1_blue = 255;
	paint.bc1 = 'rgb('+bc1_red+','+bc1_green+','+bc1_blue+')'
	paint.c1 = 'rgb('+c1_red+','+c1_green+','+c1_blue+')'
}
function writePaint(){        // Сохранение палитры цветов
	$('#c-paint').hide()	
	$.ajax({type:"POST", async:false, url:"user.php", data:{func:"writePaint",paint:paint}, dataType:"JSON",
		error:function(a){alertOn(a['responseText'],'!')}
	})
}

function readRef(val,nameRef){// Чтение записи справочника из БД
	val = val.replace(/ {1,}/g," ")
	var a = {}, id = 0
	switch (nameRef){ 
		case 'chair': a = val.split('код '); id = +a[1]; break
		case 'grup': a = val.split(' кафедра'); id = a[0]; $("#grup_ref input").val(id); break
		case 'student': a = val.split('№'); id = +a[1]; break
		case 'teacher': a = val.split(' ('); a = a[1].split(')'); id = +a[0]; break
		case 'subject': a = val.split(' ('); a = a[1].split(')'); id = +a[0]; break
	}
    ref_ = {}
	if (id == '' || id == 0) return('id = 0')	
	$.ajax({type:"POST", async:false, url:"dep.php", data:{func:"readRef",nameRef,id}, dataType:"JSON",
		success: function(a){ref_ = a; screenRef(nameRef)},
		error:function(a){alertOn(a['responseText'],'!')}
	})
}
function ref0(){              // Формирование начальных параметров справочников
	ref_ = {'id_chair':0,'chair':'','chair_full':'',
			'grup':'','level':'Бакалавриат','ofo':'ОФО','cypher':'','specialization':'','profile':'',
			'nbook':0,'student':'','grup':'','subgrup':'1','contract':'бюджет','d0':'','d_out':'','session':'есть',
			'id_teacher':0,'teacher':'','position':'','title':'','degree':'',
			'id_subject':0,'subject':''}
}
function ref_chair(val){      // Изменение параметра "chair" в переменной ref_{}
	val = val.replace(/ {1,}/g," ")
	var a = val.split(' ')
	ref_.chair = a[0]
	screenRef('chair')
}
function ref_grup(val){       // Изменение параметра "grup" в переменной ref_{}
	val = val.replace(/ {1,}/g," ")
	var a = val.split(' кафедра ')
	ref_.grup = a[0]
	screenRef('grup')
}
function chair_grup(val){     // Изменение параметра "chair" в переменной ref_{}
	val = val.replace(/ {1,}/g," ")
	var a = val.split(' ')
	ref_.chair = a[0]
	a = val.split('код ')
	ref_.id_chair = +a[1]
	val = ref_.chair
	screenRef('grup')
}
function chair_teacher(val){  // Изменение параметра "chair" в переменной ref_{}
	val = val.replace(/ {1,}/g," ")
	var a = val.split(' ')
	ref_.chair = a[0]
	a = val.split('код ')
	ref_.id_chair = +a[1]
	val = ref_.chair
	screenRef('teacher')
}
function grup_student(val){   // Изменение параметра "grup" в переменной ref_{}
	val = val.replace(/ {1,}/g," ")
	var a = val.split(' кафедра')
	ref_.grup = a[0]
	screenRef('student')
}
function id_teacher(){ref_.id_teacher = '';	screenRef('teacher')}
function id_subject(){ref_.id_subject = '';	screenRef('subject')}
function screenRef(p){        // Вывод на экран параметров справочника
	nameRef = p
	switch (nameRef){ 
		case 'chair': 
			nf = 'Кафедры' 
			s = 'Аббревиатура: <div id="chair_ref" class="select select_b" type="DB" php="searchChair" func="ref_chair(val)" width_="500"></div><br>'
			s += 'Код кафедры: <div id="id_chair" class="select select_b" type="DB" php="searchIdChair" func="ref_.id_chair=val"></div><br>'
			s += 'Название кафедры: <div id="chair_full" class="select select_b" type="DB" php="searchChairFull" func="ref_.chair_full=val"></div><br>'
			$('#c-ref0').css('top','39px')
			break
		case 'grup': 
			nf = 'Группы' 
			s = 'Группа: <div id="grup_ref" class="select select_b" type="DB" php="searchGrup" func="ref_grup(val)" width_="600"></div><br>'
			s += 'Кафедра: <div id="chair_grup" class="select select_b" type="DB" php="searchChair" func="chair_grup(val)" width_="500"></div><br>'
			s += 'Уровень образования: <div id="level_grup" class="select select_b" type="local" ref="Level" func="ref_.level=val"></div><br>'
			s += 'Форма обучения: <div id="ofo_grup" class="select select_b" type="local" ref="OFO" func="ref_.ofo=val"></div><br>'
			s += 'Шифр специальности: <div id="cypher" class="select select_b" type="DB" php="searchCypher" func="ref_.cypher=val"></div><br>'
			s += 'Направление: <div id="specialization" class="select select_b" type="DB" php="searchSpecialization" func="ref_.specialization=val"></div><br>'
			s += 'Профиль: <div id="profile" class="select select_b" type="DB" php="searchProfile" func="ref_.profile=val"></div><br>'
			$('#c-ref0').css('top','65px')
			break
		case 'student': 
			nf = 'Студенты' 
			s = '№ зачетки: <div id="nbook" class="select select_b" type="DB" php="searchNbook" func="ref_.nbook=$(this).val()"></div><br>'
			s += 'Студент: <div id="student_ref" class="select select_b" type="DB" php="searchStudent" func="searchStudent()" width_="500"></div><br>'
			s += 'Группа: <div id="ref_grup" class="select select_b" type="DB" php="searchGrup" func="grup_student(val)" width_=600></div>'
			s += ', подгруппа: <div id="subgrup" class="btn" onclick="switchSubgrup()"></div><br>'
			s += 'Условие обучения: <div id="contract" class="btn" onclick="switchContract()"></div><br>'
			s += 'Дата зачисления: <div name="d0" class="btn"><input name="datepicker" onchange="ref_.d0 =$(this).val()"></div>'
			s += ', дата отчисления: <div name="d_out" class="btn"><input name="datepicker" onchange="ref_.d_out =$(this).val()"></div><br>'
			s += 'Допуск к сессии: <div id="session" class="btn" onclick="switchSession()"></div><br>'
			$('#c-ref0').css('top','92px')
			break
		case 'teacher': 
			nf = 'Преподаватели' 
			s = 'Код преподавателя: <div id="id_teacher" class="select select_b" type="DB" php="searchIdTeacher" func="id_teacher()"></div><br>'
			s += 'Преподаватель: <div id="teacher_ref" class="select select_b" type="DB" php="searchTeacher" func="searchTeacher()"></div><br>'
			s += 'Кафедра: <div id="chair_teacher" class="select select_b" type="DB" php="searchChair" func="chair_teacher(val)" width_="500"></div><br>'
			s += 'Должность: <div id="position" class="select select_b" type="DB" php="searchPosition" func="ref_.position=val"></div><br>'
			s += 'Ученое звание: <div id="title" class="select select_b" type="DB" php="searchTitle" func="ref_.title=val"></div><br>'
			s += 'Ученая степень: <div id="degree" class="select select_b" type="DB" php="searchDegree" func="ref_.degree=val"></div><br>'
			$('#c-ref0').css('top','120px')
			break
		case 'subject': 
			nf = 'Дисциплины' 
			s = 'Код дисциплины: <div id="id_subject" class="select select_b" type="DB" php="searchIdSubject" func="id_subject()"></div><br>'
			s += 'Дисциплина: <div id="subject_ref" class="select select_b" type="DB" php="searchSubject" func="searchSubject()"></div><br>'
			$('#c-ref0').css('top','146px')
			break
	}
	$('#fieldsRef').html(s)
	selPicker("#fieldsRef")
	$("#fieldsRef [name=datepicker]").datepicker()
	$('#nameRef span').html(nf)
	switch (nameRef){ 
		case 'chair': 
			$('#chair_ref0 input,#chair_ref input').val(ref_.chair).attr('onchange','ref_.chair=$(this).val()'); $('#chair_ref').css('width','50px')
			$('#id_chair input').val(ref_.id_chair).mask("9?9",{placeholder:""}).attr('onchange','ref_.id_chair=$(this).val()'); $('#id_chair').css('width','35px')
			$('#chair_full input').val(ref_.chair_full).attr('onchange','ref_.chair_full=$(this).val()'); $('#chair_full').css('width','450px')
			break
		case 'grup': 
			$('#grup_ref0 input,#grup_ref input').val(ref_.grup).attr('onchange','ref_.grup=$(this).val()'); $('#grup_ref').css('width','130px')
			$('#chair_grup input').val(ref_.chair); $('#chair_grup').css('width','50px')
			$('#level_grup input').val(ref_.level); $('#level_grup').css('width','135px')
			$('#ofo_grup input').val(ref_.ofo); $('#ofo_grup').css('width','45px')
			$('#cypher input').val(ref_.cypher).attr('onchange','ref_.cypher=$(this).val()'); $('#cypher').css('width','75px')
			$('#specialization input').val(ref_.specialization).attr('onchange','ref_.specialization=$(this).val()'); $('#specialization').css('width','350px')
			$('#profile input').val(ref_.profile).attr('onchange','ref_.profile=$(this).val()'); $('#profile').css('width','450px')
			break
		case 'student': 
			$('#nbook input').val(ref_.nbook).mask("999999",{placeholder:""}).attr('onchange','ref_.nbook=$(this).val()'); $('#nbook').css('width','63px')
			$('#student_ref0 input,#student_ref input').val(ref_.student).attr('onchange','ref_.student=$(this).val()'); $('#student_ref').css('width','450px')
			$('#ref_grup input').val(ref_.grup); $('#ref_grup input').css('width','100px')
			$('#subgrup').html(ref_.subgrup); $('#ref_subgrup').css('font-weight','700')
			$('#contract').html(ref_.contract).css('font-weight','700')
			$('#c-ref0 [name=d0] input').val(ref_.d0)
			$('#c-ref0 [name=d_out] input').val(ref_.d_out)
			$('#session').html(ref_.session).css('font-weight','700')
			break
		case 'teacher': 
			$('#id_teacher input').val(ref_.id_teacher).attr('onchange','ref_.id_teacher=$(this).val()'); $('#id_teacher').css('width','50px')
			$('#teacher_ref0 input,#teacher_ref input').val(ref_.teacher).attr('onchange','ref_.teacher=$(this).val()'); $('#teacher_ref').css('width','450px')
			$('#chair_teacher input').val(ref_.chair); $('#chair_teacher').css('width','50px')
			$('#position input').val(ref_.position).attr('onchange','ref_.position=$(this).val()');	$('#position').css('width','250px')
			$('#title input').val(ref_.title).attr('onchange','ref_.title=$(this).val()'); $('#title').css('width','150px')
			$('#degree input').val(ref_.degree).attr('onchange','ref_.degree=$(this).val()'); $('#degree').css('width','100px')
			break
		case 'subject': 
			$('#id_subject input').val(ref_.id_subject).attr('onchange','ref_.id_subject=$(this).val()'); $('#id_subject').css('width','50px')
			$('#subject_ref0 input,#subject_ref input').val(ref_.subject).attr('onchange','ref_.subject=$(this).val()'); $('#subject_ref').css('width','550px')
			break
	}
	$('#c-ref0').show()
}
function Ref(p,nameRef){      // Запись,удаление строк справочников 
	if (p=='del' && id_user!=123){$('#c-ref0').hide(); ref_= {}; return}
	switch (nameRef){
		case 'chair': 
			if (ref_.chair == '' || ref_.id_chair == 0){alertOn('Ошибка в коде или аббревиатуре кафедры!'); return}
			break
		case 'grup': 
			if (ref_.grup == '' || ref_.id_chair == 0){alertOn('Ошибка в названии группы или в коде кафедры!'); return}
			break
		case 'student': 
			if (ref_.student == '' || ref_.nbook == 0){alertOn('Ошибка в ФИО студента или номере зачетной книжки!'); return}
			break
		case 'teacher': 
			if (ref_.teacher == '' || ref_.id_teacher == 0){alertOn('Ошибка в коде или ФИО преподавателя!'); return}
			break
		case 'subject': 
			if (ref_.subject == '' || ref_.id_subject == 0){alertOn('Ошибка в коде или названии дисциплины!'); return}
			break
	}	
	$.ajax({type:"POST", async:false, url:"dep.php", data:{func:"Ref",p,nameRef,ref_}, dataType:"JSON",
		success: function(a){alertOn(a)},
		error:function(a){alertOn(a['responseText'],'!')}
	})
}
function screenForms(){       // Вывод на экран периода и списка выходных форм
	s = '<div class="time"></div><div class="period"><div class="period">'+
			'Данные за период с <div id="d0_forms" class="btn"><input name="datepicker" onchange="d0_forms_($(this).val())"></div>'+
			'          по <div id="d1_forms" class="btn"><input name="datepicker" onchange="d1_forms_($(this).val())"></div>'+
		 '</div>'
	for (var frm in frmList){
		s += 
			'<div id="'+frm+'" class="str">'+
				'<i class="i1 fa fa-file-o"></i>'+
				'<div class="list" onclick="formTab(\''+frm+'\')">'+frmList[frm]+'</div>'+
				'<a id="'+frm+'_" href="forms/'+frm+'__'+USER.id_user+'.xlsx" download="'+frm+'__'+USER.id_user+'.xlsx">'+
					'<i class="i2 fa fa-download"></i>'+
				'</a>'+
			'</div>'	
	}
	$('#c-forms').html(s)
	$('#c-forms [name=datepicker]').datepicker()
	$("#d0_forms input").val(d0_forms)
	$("#d1_forms input").val(d1_forms)
}
function formTab(frm){        // Формирование выходной формы (таблицы) с именем frm
	if ((frm == 'f71' || frm == 'f73') && xOwn == ''){alertOn('Для выходной формы <b>таб №'+frm[1]+'.'+frm[2]+'</b> необходимо задать пользователя !','!'); return} 
	$.ajax({type:"POST", async:true, url:"dep.php", data:{func:frm,d0:d0_forms,d1:d1_forms,xP}, dataType:"JSON",
		beforeSend:function(){
			var d = new Date(); var s = d.getSeconds(); if (s < 10) s = '0'+ s
			$('.time').html(d.getMinutes()+':'+s)
			$('#'+frm+' .i2').removeClass('fa-download').addClass('fa-spinner fa-spin').css('color','rgba(14,72,116,0.6)')
		},
		complete:function(){
			$('#'+frm+' .i1').removeClass('fa-spinner').addClass('fa-file-excel-o')
			$('#'+frm+' .i2').removeClass('fa-spinner fa-spin').addClass('fa-download')
		},
		success:function(a){$('.time').html(ms(a))},
		error:function(a){alertOn(a['responseText'],'!')}
	})
}
function sort_(a){            // Сортировка ассоциативного массива
	var j = 0, b = []
	for(i in a){b[j] = i+'#'+a[i]; ++j}
	b.sort()
	a = []
	for(i in b){var c = b[i].split('#'); a[c[0]] = c[1]}
	return a
}	
function sortChr(id){         // Сортировка Chr
	var f = []	
	for (var i=0; i<Chr.length; ++i){
		var s = '1'; if (id > 0 && id == Chr[i].id_teacher) var s = '0'
		if (id > 0 && id == Chr[i].id_teacherA) s += '0'; else s += '1'
		var tf = true
		for (var k=0; k<6; k++){
			var x = 0
			switch (k){
				case 0: x = Chr[i].lections; break
				case 1: x = Chr[i].labworks; break
				case 2: x = Chr[i].practics; break
				case 3: x = Chr[i].cw; break
				case 4: x = Chr[i].cp; break
				case 5: x = 1; break
			}	
			if (x > 0) if (Chr[i].s_teacher[k] == '0' && Chr[i].s_teacherA[k] == '0') tf = false
		}
		if (tf) s += '0'; else s += '1';
		s += Chr[i].grup+'|'+i
		f[s] = i
	}
	f = sort_(f)
	var arr = [], j = 0
	for(s in f){arr[j] = Chr[f[s]]; ++j}
	Chr = arr
}		
function d_(d){               // Проверка корректности даты
	if (d == '') return ''
	var a = d.split(".")
	a[1] -= 1
	var dd = new Date(a[2],a[1],a[0])
	if ((a[2]>2000)&&(a[2]<2023)&&(dd.getFullYear() == a[2])&&(dd.getMonth()==a[1])&&(dd.getDate() == a[0])) return d
	  else {alertOn('Ошибка в дате <b>'+d+' !'); return ''}
}
function now(days){           // Формирование текущей даты + days
	if (!days) days = 0
	var d = new Date()
	d.setDate(d.getDate() + days)
	var day = d.getDate(); if (day < 10) day = '0' + day
	var month = d.getMonth() + 1; if (month < 10) month = '0' + month
	var year = d.getFullYear()
	d = day + '.' + month + '.' + year
	return(d)
}
function getDate(p){          // Получение даты dd.mm.gggg
	if (p == 'now'){
		var d = new Date()
		var day = d.getDate(); if (day < 10) day = '0' + day
		var month = d.getMonth() + 1; if (month < 10) month = '0' + month
		var year = d.getFullYear()
		d = day + '.' + month + '.' + year
	} else d = $('#c-dr input').val()
	return d
}
function compareDates(d0,d1){ // Сравнение дат
	d0 = +(d0.substr(-4)+d0.substr(3,2)+d0.substr(0,2))
	d1 = +(d1.substr(-4)+d1.substr(3,2)+d1.substr(0,2))
	if (d0 == d1) return(0)
	if (d0 > d1) return(1)
	return(-1)
}
function d_db(d){             // dd.mm.gggg -> gggg-mm-dd
	d = d.substr(-4)+'-'+d.substr(3,2)+'-'+d.substr(0,2); return(d)
}
function aD_(val){            // изменение начальной отчетной даты aD
	if (d_(val) != '') if (compareDates(val,xD) < 0) aD = val;
	$("#aD input").val(aD)
}
function xD_(val){            // изменение отчетной даты xD
	if (d_(val) == '') return 
	xD = val; $("#xD input").val(xD)
	xYear = xD.substr(-4); $("#year input").val(xYear)
	if (compareDates(aD,xD) > 0){aD = '01.01.'+xD.substr(-4); $("#aD input").val(aD)}
	d1_forms = xD
	if (compareDates(d0_forms,d1_forms) > 0){d0_forms = d1_forms; $("#d0_forms input").val(d0_forms)}
}
function d0_forms_(val){      // изменение начальной даты выходной формы d0_forms
	if (d_(val) != '') if (compareDates(val,d1_forms) <= 0) d0_forms = val;
	$("#d0_forms input").val(d0_forms);
}
function d1_forms_(val){      // изменение конечной даты выходной формы d1_forms
	if (d_(val) == '') return 
	d1_forms = val; $("#d1_forms input").val(d1_forms);
	if (compareDates(d0_forms,d1_forms) > 0){d0_forms = d1_forms; $("#d0_forms input").val(d0_forms)}
	xD = d1_forms; $("#xD input").val(xD)
	if (compareDates(aD,xD) > 0){aD = '01.01.'+xD.substr(-4); $("#aD input").val(aD)}
}
function ms(sec){             // Получение времени в формате мм:сс
	sec = Math.round(sec)
	var s = sec % 60; sec = (sec - s)/60; if (s < 10) s = '0'+s;
	s = sec + ':'+ s;
	return(s)
}
function u(s,p){              // Вывод числа на экран без нулей в конце
	s = +s;	if (s == 0 || isNaN(s)) return('')
	s = s.toFixed(p)
	while((s[s.length-1] == '0' || s[s.length-1] == '.') && s.indexOf('.') > 0) s = s.substring(0,s.length-1)
	return(s)
}
function u_(s,p){             // Вывод числа на экран
	s = +s;	if (s == 0 || isNaN(s)) return('')
	s = s.toFixed(p)
	return(s)
}
function u_calc(s){           // Вычисляемый параметр val
	var r = 0
	if (~s.indexOf('*')) r = '*'; else {
		s = $.trim(s.replace(',','.'))
		var a = s.split('+'), r = 0
		for (var i=0; i<a.length; i++){
			var b = $.trim(a[i]).split('-'), rm = 1*$.trim(b[0])
			for (var j=1; j<b.length; j++) rm = rm - 1*$.trim(b[j])
			r += rm
		}
	}
	if (r != '*' && isNaN(r)) r = 0
	return(r)
}
