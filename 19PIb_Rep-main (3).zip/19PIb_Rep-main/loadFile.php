<?php
	require_once('lib.php');
//	$user = access();
//	if ($user['access'] < 1) mes('Вам ещё не открыт доступ!<br>Обратитесь к <i>Администратору ИС-С</i>, чтобы получить <b>права доступа</b>.');
	$file = "No";
	if (isset($_GET['file'])) $file = "files/".$_GET['file'];
	file_force_download($file);
	$file = iconv('UTF-8', 'CP1251', $file);
	if (!isset($_GET['file'])) unlink($file);
function file_force_download($file){
    // сбрасываем буфер вывода PHP, чтобы избежать переполнения памяти выделенной под скрипт
    // если этого не сделать файл будет читаться в память полностью!
	$fn = $file;
	$file = iconv('UTF-8', 'CP1251', $file);
	if (file_exists($file)){
		if (ob_get_level()){ob_end_clean();}
		// заставляем браузер показать окно сохранения файла
		header('Content-Description: File Transfer');
		header('Content-Type: application/octet-stream');
		$file_name=str_replace(" ","_",$file);
		header('Content-Disposition: attachment; filename=' . basename($file_name));
		header('Content-Transfer-Encoding: binary');
		header('Expires: 0');
		header('Cache-Control: must-revalidate');
		header('Pragma: public');
		header('Content-Length: ' . filesize($file));
		// читаем файл и отправляем его пользователю
		readfile($file);
		return(0);
	} else mes('Файл - <b>'.$fn.'</b> - в папке хранения отсутствует!');
}
?>