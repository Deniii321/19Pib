<?php # Библиотека php-функций "старт"
header("content-type: text/html; charset= UTF-8");
$old_error_handler = set_error_handler("myErrorHandler");
$ip = get_ip();
class DB{
	public static $mysqli;
	public static function connect(){
//		self::$mysqli = new mysqli("127.0.0.1", "root", "", "depDB");
		self::$mysqli = new mysqli("10.107.7.60", "root", "", "depDB");
		self::$mysqli->set_charset("utf8");
		if (self::$mysqli->connect_errno){mes('Нет соединения с MySQL');}}}
DB::connect();
function mes($s){trigger_error($s, E_USER_ERROR);}
function myErrorHandler($errno, $errstr, $errfile, $errline){
	if (!(error_reporting() & $errno)){return;}  # Этот код ошибки не включен в error_reporting
	switch ($errno){
		case E_USER_ERROR: echo $errstr; exit(1); break;
		case E_USER_WARNING: echo "<b>My WARNING</b> [$errno] $errstr<br />\n";	break;
		case E_USER_NOTICE:	echo "<b>My NOTICE</b> [$errno] $errstr<br />\n"; break;}
	return false;
}
function get_ip(){
	if(getenv("HTTP_CLIENT_IP")) {$ip = getenv("HTTP_CLIENT_IP");}
		elseif(getenv("HTTP_X_FORWARDED_FOR")){$ip = getenv("HTTP_X_FORWARDED_FOR");} 
		else{$ip = getenv("REMOTE_ADDR");}
	if (empty($ip) || $ip=='unknown') exit('ip не установлен !');
	return $ip;
}
function access(){
	if (isset($_COOKIE['hash'])){
		$hash = $_COOKIE['hash'];
		$res = DB::$mysqli->query("SELECT id_user,access,own FROM users WHERE hash='$hash'");
		$row = $res->fetch_row();
		if (!$row[0]) mes('Вы не зарегистрировались!');
		$a = ['id'=>$row[0],'access'=>$row[1],'own'=>$row[2]];
		return ($a);
	}
	mes('Вы не зарегистрировались!');
	exit;
}
function get_user_id(){
	if (isset($_COOKIE['hash'])){
		$hash = $_COOKIE['hash'];
		session_name($hash);
		session_start();
		if (isset($_SESSION['id_user'])){session_write_close();	return ($_SESSION['id_user']);}
		else {
			$result = DB::$mysqli->query("SELECT id_user FROM users WHERE hash='$hash'");
			$row = $result->fetch_row();
			$result->close();
			if ($row[0]){
				$_SESSION['id_user']=$row[0];
				session_write_close();
				return ($row[0]);}}}
	else {session_write_close(); return(0);}
}
function attemptsGet($ip,$prm,$tm){
	DB::$mysqli->query("DELETE FROM attempts WHERE ip='$ip' AND prm='$prm' AND UNIX_TIMESTAMP()-UNIX_TIMESTAMP(tm)>('$tm'-30)");
	$res = DB::$mysqli->query("SELECT att,'$tm'-UNIX_TIMESTAMP()+UNIX_TIMESTAMP(tm) FROM attempts WHERE ip='$ip' AND prm='$prm'" );
	$att = $res->fetch_row();
	if ($att[0] == '') DB::$mysqli->query("INSERT INTO attempts (prm,ip,att) VALUES ('$prm','$ip','1')");
	else DB::$mysqli->query("UPDATE attempts SET att=($att[0]+1) WHERE ip='$ip' AND prm='$prm'");	
	return $att;
}
?>