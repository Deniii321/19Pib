<?php # Библиотека php-функций 
	ini_set('memory_limit','1024M');
	set_time_limit(6000);
	require_once 'lib.php';
	$f = dirname(__FILE__).'\PhpSpreadsheet\PhpSpreadsheet.php';
	if (file_exists($f)) require_once $f; else mes('Отсутствует файл '.$f.' !');
	$f = dirname(__FILE__).'\phpWord\autoload.php';
	if (file_exists($f)) require_once $f; else mes('Отсутствует файл '.$f.' !');
	$user = access();
 	if ($user['access'] < 1) mes('Вам ещё не открыт доступ!<br>Обратитесь к <b>Администратору ИС</b>, чтобы получить <b>права доступа</b>.');
	if ($user['access'] != 1 AND $user['access'][0] != '5') mes('У Вас нет допуска к информации! <br>Обратитесь к Администратору ИС, чтобы получить <b>права доступа</b>.');
	$id = $user['id'];
	$id_own = $user['own'];
	if ($id_own == '' AND $user['access'] > 6) mes('Не определен код пользователя! <br>Обратитесь к <b>Администратору ИС</b>.');
	$func = $_POST['func'];
	switch ($func ){
 		case 'f12': f12($id); break;
 		case 'f13': f13($id); break;
 		case 'f14': f14($id); break;
 		case 'f23': f23($id); break;
		case 'f26': f26($id); break;
		case 'searchLogin': searchLogin(); break;
		case 'searchChair': searchChair(); break;
		case 'searchIdChair': searchIdChair(); break;
		case 'searchChairFull': searchChairFull(); break;
		case 'searchGrup': searchGrup(); break;
		case 'searchCypher': searchCypher(); break;
		case 'searchSpecialization': searchSpecialization(); break;
		case 'searchProfile': searchProfile(); break;
		case 'searchStudent': searchStudent(); break;
		case 'searchNbook': searchNbook(); break;
		case 'searchTeacher': searchTeacher(); break;
		case 'searchIdTeacher': searchIdTeacher(); break;
		case 'searchPosition': searchPosition(); break;
		case 'searchTitle': searchTitle(); break;
		case 'searchDegree': searchDegree(); break;
		case 'readChr': readChr(); break;
		case 'writeChr': writeChr(); break;
		case 'readDek': readDek(); break;
		case 'writeDek': writeDek(); break;
		case 'readRep': readRep(); break;
		case 'writeRep': writeRep(); break;
		case 'readSheetV': readSheetV(); break;
		case 'readSheet': readSheet(); break;
		case 'writeSheet': writeSheet(); break;
		case 'readChair': readChair(); break;
		case 'searchSubject': searchSubject(); break;
		case 'searchIdSubject': searchIdSubject(); break;
		case 'readRef': readRef(); break;
		case 'Ref': Ref(); break;
	}

function f12($id){               # форма 1.2 Индивидуальный план
	$time = microtime(true);
	$xP = $_POST['xP'];
	$id_teacher0 = (int)$xP['id_teacher'];
	if ($id_teacher0 < 1) mes(' Нужно задать имя преподавателя! ');
	$inputFileName = 'forms/temp/f12-temp.xlsx';
	$reader = new PhpOffice\PhpSpreadsheet\Reader\Xlsx;	$objPHPExcel = $reader->load($inputFileName);
	$objPHPExcel->getActiveSheet()->setCellValue('C8','на '.$xP['years'].' учебный год');
	$res1 = DB::$mysqli->query("SELECT * FROM teachers WHERE id_teacher='$id_teacher0'"); $row1=$res1->fetch_assoc();
	$id_chair = $row1['id_chair'];
	$res2 = DB::$mysqli->query("SELECT chair_full FROM chairs WHERE id_chair='$id_chair'"); $row2=$res2->fetch_row();
	$objPHPExcel->getActiveSheet()->setCellValue('A10','Кафедра "'.$row2[0].'"');
	$objPHPExcel->getActiveSheet()->setCellValue('C12',$row1['teacher'].', '.$row1['position'].', '.$row1['title']);
	$stavka = $xP['stavka']; $s = $stavka;
	switch ($stavka){
		case '1': $s = 'ставка'; break;
		case '1/2': $s = 'полставки'; break;
		case '0,75': $s = 'совместительство 0,75 ставки'; break;
		case '0,5': $s = 'совместительство 0,5 ставки'; break;
		case '0,25': $s = 'совместительство 0,25 ставки'; break;
		case 'час': $s = 'почасовая оплата'; break;
	}
	$objPHPExcel->getActiveSheet()->setCellValue('C13','( '.$s.' )');
	$res = DB::$mysqli->query("SELECT * FROM catalog WHERE (id_teacher='$id_teacher0' AND stavka='$stavka') OR (id_teacherA='$id_teacher0' AND stavkaA='$stavka')");
	$J_ = []; $J_[1]=21; $J_[2]=64; $J_[3]=107; $J_[4]=128; $J_[11]=148; $J_[12]=191; $J_[13]=234; $J_[14]=257;
	for ($i=0; $row=$res->fetch_assoc(); $i++){
		$grup = $row['grup'];
		$semestr = $row['semestr'];
		$s1 = ((int)mb_substr($xP['years'],2,2) - (int)mb_substr($grup,0,2))*2+1;
		$s2 = ((int)mb_substr($xP['years'],7,2) - (int)mb_substr($grup,0,2))*2;
        if ($s1 != $semestr AND $s2 != $semestr) continue;
		$res1 = DB::$mysqli->query("SELECT level FROM grups WHERE grup='$grup'"); $row1=$res1->fetch_row();
		if ($row['semestr'] % 2 == 0) $J0 = 10; else $J0 = 0;
		switch ($row1[0]){
			case 'Специалитет': $J0 += 1; break;
			case 'Бакалавриат': $J0 += 2; break;
			case 'Магистратура': $J0 += 3; break;
			case 'Аспирантура': $J0 += 4; break;
		}
		$J_[$J0]=$J_[$J0]+2; $J = $J_[$J0];
		$id_subject = $row['id_subject'];
		$res1 = DB::$mysqli->query("SELECT subject FROM subjects WHERE id_subject='$id_subject'"); $row1=$res1->fetch_row();
		$objPHPExcel->getActiveSheet()->setCellValue('A'.$J,$row1[0]);
		$objPHPExcel->getActiveSheet()->setCellValue('B'.$J,$grup);
		$res1 = DB::$mysqli->query("SELECT * FROM students WHERE grup='$grup'");
		$N0 = 1; $N1 = 0; $N2 = 0; $d0 = strtotime(mb_substr($xP['years'],0,4).'-09-01');
		for ($i1=0; $row1=$res1->fetch_assoc(); $i1++){
			if (strtotime($row1['d0']) > $d0) continue;
			if ($row1['d_out'] != '2000-01-01' AND strtotime($row1['d_out']) < $d0) continue;
			if ($row1['contract'] == 'бюджет') ++$N1; else ++$N2;
			if ($row1['subgrup'] > 1) $N0 = 2;
		}
		$objPHPExcel->getActiveSheet()->setCellValue('C'.$J,$N0);
		$objPHPExcel->getActiveSheet()->setCellValue('E'.$J,$N1);
		$objPHPExcel->getActiveSheet()->setCellValue('E'.($J+1),$N2);
		$id_teacher = $row['id_teacher']; $x = $row['s_teacher'];
		if ($row['id_teacherA'] == $id_teacher0 AND $row['stavkaA'] == $stavka) $x = $row['s_teacherA'];
		if (in_array($id_subject,[94,95,96,97,98,141,143])){
			$objPHPExcel->getActiveSheet()->setCellValue('AR'.$J,2*($N1+$N2));
		} else {
			if ($x[0] == '1') $s = $row['lections']; else $s = 0; $objPHPExcel->getActiveSheet()->setCellValue('F'.$J,$s);
			if ($x[1] == '1') $s = $row['labworks']; else $s = 0; $objPHPExcel->getActiveSheet()->setCellValue('J'.$J,$s*$N0);
			if ($x[2] == '1') $s = $row['practics']; else $s = 0; $objPHPExcel->getActiveSheet()->setCellValue('H'.$J,$s*$N0);
			if ($row['cw'] > 0 AND $x[3] == '1'){
				$objPHPExcel->getActiveSheet()->setCellValue('N'.$J,2*($N1+$N2));
				$objPHPExcel->getActiveSheet()->setCellValue('X'.$J,0.5*($N1+$N2));
			}	
			if ($row['cp'] > 0 AND $x[4] == '1'){
				$objPHPExcel->getActiveSheet()->setCellValue('N'.$J,3*($N1+$N2));
				$objPHPExcel->getActiveSheet()->setCellValue('X'.$J,0.5*($N1+$N2));
			}	
			if ($row['typefos'] == 'Экзамен' AND $x[5] == '1'){
				$objPHPExcel->getActiveSheet()->setCellValue('R'.$J,1);
				$objPHPExcel->getActiveSheet()->setCellValue('AB'.$J,0.25*($N1+$N2));
			}	
		}	
	}
	for ($i=25; $i<($J_[1]+2); $i++) $objPHPExcel->getActiveSheet()->getRowDimension($i)->setVisible(true);
	for ($i=68; $i<($J_[2]+2); $i++) $objPHPExcel->getActiveSheet()->getRowDimension($i)->setVisible(true);
	for ($i=111; $i<($J_[3]+2); $i++) $objPHPExcel->getActiveSheet()->getRowDimension($i)->setVisible(true);
	for ($i=132; $i<($J_[4]+2); $i++) $objPHPExcel->getActiveSheet()->getRowDimension($i)->setVisible(true);
	for ($i=152; $i<($J_[11]+2); $i++) $objPHPExcel->getActiveSheet()->getRowDimension($i)->setVisible(true);
	for ($i=195; $i<($J_[12]+2); $i++) $objPHPExcel->getActiveSheet()->getRowDimension($i)->setVisible(true);
	for ($i=238; $i<($J_[13]+2); $i++) $objPHPExcel->getActiveSheet()->getRowDimension($i)->setVisible(true);
	for ($i=261; $i<($J_[14]+2); $i++) $objPHPExcel->getActiveSheet()->getRowDimension($i)->setVisible(true);
	$objWriter = new PhpOffice\PhpSpreadsheet\Writer\Xlsx($objPHPExcel);
	$objWriter->save($_SERVER['DOCUMENT_ROOT']."/forms/f12__".$id.".xlsx");
	exit(json_encode(microtime(true)-$time));
}

function p_($s){if ($s <= 0) $s = ''; return $s;}
function font0($J,$objPHPExcel){
	$objPHPExcel->getActiveSheet()->mergeCells('A'.$J.':BX'.$J);
	$objPHPExcel->getActiveSheet()->getStyle('A'.$J.':BX'.$J)->getBorders()->getOutline()->setBorderStyle(\PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THIN);
	$objPHPExcel->getActiveSheet()->getStyle('A'.$J)->getFill()->setFillType(\PhpOffice\PhpSpreadsheet\Style\Fill::FILL_SOLID)->getStartColor('f5f5f5')->setARGB('f5f5f5');
	$objPHPExcel->getActiveSheet()->getStyle('A'.$J)->getAlignment()->setHorizontal(\PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_LEFT);
	$objPHPExcel->getActiveSheet()->getStyle('A'.$J)->getFont()->setSize(12)->setBold(true);
}

function f12($id){               # форма 1.2 Учебный план
	$time = microtime(true);
	$xP = $_POST['xP'];
	$grup = $xP['grup'];
	$inputFileName = 'forms/temp/f12-temp.xlsx';
	$reader = new PhpOffice\PhpSpreadsheet\Reader\Xlsx;	$objPHPExcel = $reader->load($inputFileName);
	$res = DB::$mysqli->query("SELECT * FROM grups WHERE grup='$grup'"); $row = $res->fetch_assoc();
	$s = 'Учебный план '; 
	switch ($row['B']){
		case 'B': $s .= 'бакалавриата'; break;
		case 'M': $s .= 'магистратуры'; break;
		case 'S': $s .= 'специалитета'; break;
	}
	$s .= ' '.$grup.', код направления '.$row['cypher'].', профиль: '.$row['profile'].', год начала подготовки 20'.mb_substr($grup,0,2);
	$objPHPExcel->getActiveSheet()->setCellValue('C1',$s);                                               
	$Bs0 = []; $Bs = []; for ($k=8; $k<73; $k++){$Bs0[$k] = 0; $Bs[$k] = 0;}
	$arr0 = [0=>'',1=>'']; $bl0 = '';
	$res = DB::$mysqli->query("SELECT * FROM subject_h WHERE grup='$grup' ORDER BY I"); if (!$res) mes("> ".DB::$mysqli->error);
	$J = 4; $tf = false;
	for ($i=0; $row=$res->fetch_assoc(); $i++){
		++$J;
		$arr = explode('.',$row['B']);
		if ($arr0[1] != $arr[1] AND $arr0[1] != '' AND $arr[0] != 'ФТД'){
			$objPHPExcel->getActiveSheet()->mergeCells('A'.$J.':H'.$J);
			$objPHPExcel->getActiveSheet()->getStyle('A'.$J.':BX'.$J)->getFill()->setFillType(\PhpOffice\PhpSpreadsheet\Style\Fill::FILL_SOLID)->getStartColor('f5f5f5')->setARGB('f5f5f5');
			for ($k=8; $k<73; $k++){$objPHPExcel->getActiveSheet()->setCellValue(colexcel($k).$J,p_($Bs0[$k])); $Bs0[$k] = 0;}
			++$J;
		}                                               
		if ($arr0[0] != $arr[0] AND $arr0[0] != ''){
			$objPHPExcel->getActiveSheet()->mergeCells('A'.$J.':H'.$J);
			$objPHPExcel->getActiveSheet()->getStyle('A'.$J.':BX'.$J)->getFill()->setFillType(\PhpOffice\PhpSpreadsheet\Style\Fill::FILL_SOLID)->getStartColor('f5f5f5')->setARGB('f5f5f5');
			for ($k=8; $k<73; $k++){$objPHPExcel->getActiveSheet()->setCellValue(colexcel($k).$J,p_($Bs[$k])); $Bs[$k] = 0;}
			++$J;
		}                                               
		if ($arr0[0] != $arr[0]){
			$s = '';
			switch ($arr[0]){
				case 'Б1': $s .= 'Блок 1.Дисциплины(модули)'; break;
				case 'Б2': $s .= 'Блок 2.Практика'; break;
				case 'Б3': $s .= 'Блок 3.Государственная итоговая аттестация'; break;
				case 'ФТД': $s .= 'ФТД.Факультативы'; break;
			}
			if ($s != ''){font0($J,$objPHPExcel); $objPHPExcel->getActiveSheet()->setCellValue('A'.$J,$s); ++$J;}
		}	
		if ($arr0[1] != $arr[1]){
			$s = '';
			switch ($arr[1]){
				case 'О': $s .= 'Обязательная часть'; break;
				case 'В': $s .= 'Часть, формируемая участниками образовательных отношений'; break;
			}
			if ($s != ''){font0($J,$objPHPExcel); $objPHPExcel->getActiveSheet()->setCellValue('A'.$J,$s); ++$J;}
		}
		if ($arr[4]){
			$bl = $arr[0].'.'.$arr[1].'.'.$arr[2].'.'.$arr[3];
			if ($bl0 != $bl){
				$objPHPExcel->getActiveSheet()->setCellValue('A'.$J,'+'); 
				$objPHPExcel->getActiveSheet()->setCellValue('B'.$J,$bl); 
				if ($bl == 'Б1.О.ДВ.01') $s = 'Элективные курсы по физической культуре и спорту'; else $s = 'Дисциплины по выбору '.$bl;
				$objPHPExcel->getActiveSheet()->getStyle('C'.$J)->getFont()->setBold(true);
				$objPHPExcel->getActiveSheet()->setCellValue('C'.$J,$s); 
				++$J; $tf = true;
			}
			$bl0 = $bl;	
		}
		$arr0 = $arr;
		if ($row['A'] == 1) $s = '+'; else $s = '-';
		$objPHPExcel->getActiveSheet()->setCellValue('A'.$J,$s);                                               
		$objPHPExcel->getActiveSheet()->setCellValue('B'.$J,$row['B']);                                               
		$id_subject = $row['id_subject'];
		$res1 = DB::$mysqli->query("SELECT subject FROM subject_n WHERE id_subject='$id_subject'"); if (!$res1) mes("> ".DB::$mysqli->error);
		$row1=$res1->fetch_row();
		$objPHPExcel->getActiveSheet()->setCellValue('C'.$J,$row1[0]);                                               
		$id_chair = $row['id_chair'];
		$res1 = DB::$mysqli->query("SELECT chair_full FROM chairs WHERE id_chair='$id_chair'"); if (!$res1) mes("> ".DB::$mysqli->error);
		$row1=$res1->fetch_row();
		$objPHPExcel->getActiveSheet()->setCellValue('BV'.$J,$id_chair);                                               
		$objPHPExcel->getActiveSheet()->setCellValue('BW'.$J,$row1[0]);                                               
		$objPHPExcel->getActiveSheet()->setCellValue('BX'.$J,$row['competentions']);                                               
		$res1 = DB::$mysqli->query("SELECT * FROM subject WHERE (grup='$grup' AND id_subject = '$id_subject')"); if (!$res1) mes("> ".DB::$mysqli->error);
		$B = []; for ($k=3; $k<73; $k++) if ($k < 8) $B[$k] = ''; else $B[$k] = 0;
		for ($i1=0; $row1=$res1->fetch_assoc(); $i1++){
			$C = 10+7*$row1['semestr'];
			switch ($row1['typefos']){
				case 'Экзамен': $B[3] .= $row1['semestr']; break;
				case 'Зачёт': $B[4] .= $row1['semestr']; break;
				case 'Зачёт с оценкой': $B[5] .= $row1['semestr']; break;
			}
			if ($row1['cp'] > 0) $B[6] .= $row1['semestr'];
			if ($row1['cw'] > 0) $B[7] .= $row1['semestr'];
			$sum = $row1['lections']+$row1['labworks']+$row1['practics']+$row1['indepworks']+$row1['control'];
			$ed = u_($sum/36,0);
			$B[8] += +$ed;
			$B[9] = $B[8];
			$B[10] = 36;
			$B[11] += $sum;
			$B[12] = $B[11];
			$B[13]	+= $row1['lections']+$row1['labworks']+$row1['practics'];	
			$B[14]	+= $row1['indepworks'];	
			$B[15]	+= $row1['control'];	
			$B[16]	+= 0; // ИНТЕРЧАСЫ	
			if ($sum > 0){
				$B[$C] = $ed;
				$B[$C+1] = $sum;
				$B[$C+2] = $row1['lections'];
				$B[$C+3] = $row1['labworks'];
				$B[$C+4] = $row1['practics'];
				$B[$C+5] = $row1['indepworks'];
				$B[$C+6] = $row1['control'];
			}
		}
		if ($tf){
			for ($k=3; $k<73; $k++){
				if ($k == 8 OR ($k>16 AND ($k-10)%7 == 0)) $objPHPExcel->getActiveSheet()->getStyle(colexcel($k).($J-1))->getFill()->setFillType(\PhpOffice\PhpSpreadsheet\Style\Fill::FILL_SOLID)->getStartColor('f5f5f5')->setARGB('f5f5f5');
				$objPHPExcel->getActiveSheet()->setCellValue(colexcel($k).($J-1),p_($B[$k]));
				if ($k > 7){$Bs0[$k] += $B[$k]; $Bs[$k] += $B[$k];}
			}	
			$tf = false;
		}	
		for ($k=3; $k<73; $k++){
			if ($k == 8 OR ($k>16 AND ($k-10)%7 == 0)) $objPHPExcel->getActiveSheet()->getStyle(colexcel($k).$J)->getFill()->setFillType(\PhpOffice\PhpSpreadsheet\Style\Fill::FILL_SOLID)->getStartColor('f5f5f5')->setARGB('f5f5f5');
			$objPHPExcel->getActiveSheet()->setCellValue(colexcel($k).$J,p_($B[$k]));
		}		
		for ($k=8; $k<73; $k++) if (!$arr[4] AND $k != 10){$Bs0[$k] += $B[$k]; $Bs[$k] += $B[$k];}
	}
	++$J;
	$objPHPExcel->getActiveSheet()->mergeCells('A'.$J.':H'.$J);
	$objPHPExcel->getActiveSheet()->getStyle('A'.$J.':BX'.$J)->getFill()->setFillType(\PhpOffice\PhpSpreadsheet\Style\Fill::FILL_SOLID)->getStartColor('f5f5f5')->setARGB('f5f5f5');
	for ($k=8; $k<73; $k++){$objPHPExcel->getActiveSheet()->setCellValue(colexcel($k).$J,p_($Bs[$k])); $Bs[$k] = 0;}
	$objWriter = new PhpOffice\PhpSpreadsheet\Writer\Xlsx($objPHPExcel);
	$objWriter->save($_SERVER['DOCUMENT_ROOT']."/forms/f12__".$id.".xlsx");
	exit(json_encode(microtime(true)-$time));
}
/*
function f13_exel($objPHPExcel,$arr){
	$J;
	for ($JJ=0; $JJ < count($arr); $JJ++){
		$N0 = $arr[$JJ]['N0'];
		$N1 = $arr[$JJ]['N1'];
		$N2 = $arr[$JJ]['N2'];
		$objPHPExcel->getActiveSheet()->setCellValue('A'.$J,$arr[$JJ]['subject']);
		$objPHPExcel->getActiveSheet()->setCellValue('B'.$J,$arr[$JJ]['grup']);
		$objPHPExcel->getActiveSheet()->setCellValue('D'.$J,$N0);
		$objPHPExcel->getActiveSheet()->setCellValue('F'.$J,$N1);
		$objPHPExcel->getActiveSheet()->setCellValue('F'.($J+1),$N2);
		$objPHPExcel->getActiveSheet()->setCellValue('AT'.$J,$arr[$JJ]['teacher']);
		if (in_array($arr[$JJ]['id_subject'],[94,95,96,97,98,141,143])){
			$objPHPExcel->getActiveSheet()->setCellValue('AM'.$J,2*($N1+$N2));
		} else {
			if ($x[0] == '1') $s = $arr[$JJ]['lections']; else $s = 0; $objPHPExcel->getActiveSheet()->setCellValue('G'.$J,$s);
			if ($x[1] == '1') $s = $arr[$JJ]['labworks']; else $s = 0; $objPHPExcel->getActiveSheet()->setCellValue('K'.$J,$s*$N0);
			if ($x[2] == '1') $s = $arr[$JJ]['practics']; else $s = 0; $objPHPExcel->getActiveSheet()->setCellValue('I'.$J,$s*$N0);
			if ($row['cw'] > 0 AND $x[3] == '1'){
				$objPHPExcel->getActiveSheet()->setCellValue('Q'.$J,2*($N1+$N2));
				$objPHPExcel->getActiveSheet()->setCellValue('W'.$J,0.5*($N1+$N2));
			}	
			if ($row['cp'] > 0 AND $x[4] == '1'){
				$objPHPExcel->getActiveSheet()->setCellValue('O'.$J,3*($N1+$N2));
				$objPHPExcel->getActiveSheet()->setCellValue('Y'.$J,0.5*($N1+$N2));
			}	
			if ($row['typefos'] == 'Экзамен' AND $x[5] == '1'){
				$objPHPExcel->getActiveSheet()->setCellValue('S'.$J,1);
				$objPHPExcel->getActiveSheet()->setCellValue('Y'.$J,0.25*($N1+$N2));
			}	
		}

	}
}
*/
function f13($id){               # форма 1.3 Расчет нагрузки
	$time = microtime(true);
	$xP = $_POST['xP'];
	$id_chair = (int)$xP['id_chair'];
	$id_chair = 23; //if ($id_chair < 1) mes(' Нужно задать кафедру! ');
	$inputFileName = 'forms/temp/f13-temp.xlsx';
	$reader = new PhpOffice\PhpSpreadsheet\Reader\Xlsx;	$objPHPExcel = $reader->load($inputFileName);
	$objPHPExcel->getActiveSheet()->setCellValue('K4','Расчет учебной нагрузки на '.$xP['years'].' учебный год');
	$res2 = DB::$mysqli->query("SELECT chair_full FROM chairs WHERE id_chair='$id_chair'"); $row2=$res2->fetch_row();
	$objPHPExcel->getActiveSheet()->setCellValue('Y6','Кафедра "'.$row2[0].'"');
	$res = DB::$mysqli->query("SELECT * FROM subject_h,subject WHERE subject_h.grup=subject.grup AND subject_h.id_subject=subject.id_subject AND id_chair='$id_chair' ORDER BY subject_h.id_subject");
	$J0 = 11; $J1 = 424;
	for ($i=0; $row=$res->fetch_assoc(); $i++){
		$grup = $row['grup'];
		$semestr = $row['semestr'];
		$s1 = ((int)mb_substr($xP['years'],2,2) - (int)mb_substr($grup,0,2))*2+1;
		$s2 = ((int)mb_substr($xP['years'],7,2) - (int)mb_substr($grup,0,2))*2;
        if ($s1 != $semestr AND $s2 != $semestr) continue;
		$res1 = DB::$mysqli->query("SELECT * FROM students WHERE grup='$grup'");
		$N0 = 1; $N1 = 0; $N2 = 0; $d0 = strtotime(mb_substr($xP['years'],0,4).'-09-01');
		for ($i1=0; $row1=$res1->fetch_assoc(); $i1++){
			if (strtotime($row1['d0']) > $d0) continue;
			if ($row1['d_out'] != '2000-01-01' AND strtotime($row1['d_out']) < $d0) continue;
			if ($row1['contract'] == 'бюджет') ++$N1; else ++$N2;
			if ($row1['subgrup'] > 1) $N0 = 2;
		}
		if (($N1+$N2) < 1) continue;
		if ($row['A'] == 0) continue;   //Пропуск дисциплин с индексом 0
		if ($semestr % 2 == 0){$J1 = $J1+2; $J = $J1;} else {$J0 = $J0+2; $J = $J0;};
		$id_subject = $row['id_subject'];
		$res1 = DB::$mysqli->query("SELECT subject FROM subject_n WHERE id_subject='$id_subject'"); $row1=$res1->fetch_row();
		$objPHPExcel->getActiveSheet()->setCellValue('A'.$J,$row1[0]);
		$objPHPExcel->getActiveSheet()->setCellValue('B'.$J,$grup);
		$objPHPExcel->getActiveSheet()->setCellValue('D'.$J,$N0);
		$objPHPExcel->getActiveSheet()->setCellValue('F'.$J,$N1);
		$objPHPExcel->getActiveSheet()->setCellValue('F'.($J+1),$N2);
		
		$id_teacher = $row['id_teacher']; $x = $row['s_teacher'];
		$res2 = DB::$mysqli->query("SELECT teacher FROM teachers WHERE id_teacher='$id_teacher'"); $row2=$res2->fetch_row();
		$ar = explode(" ", $row2[0]); $s1 = ''; if ($ar[1]){$s1 = mb_substr($ar[1],0,1,"UTF-8").'.';}; $s2 = ''; if ($ar[2]){$s2 = mb_substr($ar[2],0,1,"UTF-8").'.';} 
		$objPHPExcel->getActiveSheet()->setCellValue('AT'.$J,$ar[0].' '.$s1.$s2);

		$id_teacherA = $row['id_teacherA']; $xA = $row['s_teacherA'];
		if ($id_teacher == $id_teacherA) $id_teacherA = 0; 
		if ($id_teacherA > 0){
			$res2 = DB::$mysqli->query("SELECT teacher FROM teachers WHERE id_teacher='$id_teacherA'"); $row2=$res2->fetch_row();
			$ar = explode(" ", $row2[0]); $s1 = ''; if ($ar[1]){$s1 = mb_substr($ar[1],0,1,"UTF-8").'.';}; $s2 = ''; if ($ar[2]){$s2 = mb_substr($ar[2],0,1,"UTF-8").'.';} 
			$objPHPExcel->getActiveSheet()->setCellValue('AT'.($J+1),$ar[0].' '.$s1.$s2);
		}
		if (in_array($id_subject,[94,95,96,97,98,141,143])){
			$objPHPExcel->getActiveSheet()->setCellValue('AM'.$J,2*($N1+$N2));
		} else {
			if ($x[0] == '1' OR $xA[0] == '1') $s = $row['lections']; else $s = 0; $objPHPExcel->getActiveSheet()->setCellValue('G'.$J,$s);
			if ($x[1] == '1' OR $xA[1] == '1') $s = $row['labworks']; else $s = 0; $objPHPExcel->getActiveSheet()->setCellValue('K'.$J,$s*$N0);
			if ($x[2] == '1' OR $xA[2] == '1') $s = $row['practics']; else $s = 0; $objPHPExcel->getActiveSheet()->setCellValue('I'.$J,$s*$N0);
			if ($row['cw'] > 0 AND ($x[3] == '1' OR $xA[3] == '1')){
				$objPHPExcel->getActiveSheet()->setCellValue('Q'.$J,2*($N1+$N2));
				$objPHPExcel->getActiveSheet()->setCellValue('W'.$J,0.5*($N1+$N2));
			}	
			if ($row['cp'] > 0 AND ($x[4] == '1' OR $xA[4] == '1')){
				$objPHPExcel->getActiveSheet()->setCellValue('O'.$J,3*($N1+$N2));
				$objPHPExcel->getActiveSheet()->setCellValue('Y'.$J,0.5*($N1+$N2));
			}	
			if ($row['typefos'] == 'Экзамен' AND ($x[5] == '1' OR $xA[5] == '1')){
				$objPHPExcel->getActiveSheet()->setCellValue('S'.$J,1);
				$objPHPExcel->getActiveSheet()->setCellValue('Y'.$J,0.25*($N1+$N2));
			}	
			if ($id_subject == '99'){                                                       //Учет часов для ВКР
				$objPHPExcel->getActiveSheet()->setCellValue('AC'.$J,15*($N1+$N2));
				$objPHPExcel->getActiveSheet()->setCellValue('AE'.$J,2*($N1+$N2));
				$objPHPExcel->getActiveSheet()->setCellValue('AI'.$J,0.5*($N1+$N2));
				$objPHPExcel->getActiveSheet()->setCellValue('AK'.$J,5.5*($N1+$N2));
				$objPHPExcel->getActiveSheet()->setCellValue('AO'.$J,1*($N1+$N2));
				$objPHPExcel->getActiveSheet()->setCellValue('AQ'.$J,1*($N1+$N2));
			}
		}
	}
	for ($i=15; $i<($J0+2); $i++) $objPHPExcel->getActiveSheet()->getRowDimension($i)->setVisible(true);
	for ($i=428; $i<($J1+2); $i++) $objPHPExcel->getActiveSheet()->getRowDimension($i)->setVisible(true);

	$xls->setActiveSheetIndex(1);
	$sheet = $xls->getActiveSheet();
	$sheet->setTitle('РН(ЗФО)');
	$sheet->getActiveSheet()->setCellValue('A'.$J,$row1[0]);
	$sheet->getActiveSheet()->setCellValue('B'.$J,$grup);

	$objWriter = new PhpOffice\PhpSpreadsheet\Writer\Xlsx($objPHPExcel);
	$objWriter->save($_SERVER['DOCUMENT_ROOT']."/forms/f13__".$id.".xlsx");
	exit(json_encode(microtime(true)-$time));
}
function f14($id){               # форма 1.4 Расчет нагрузки преподавателя
	$time = microtime(true);
	$xP = $_POST['xP'];
	$id_teacher0 = (int)$xP['id_teacher'];
	if ($id_teacher0 < 1) mes(' Нужно задать имя преподавателя! ');
	$inputFileName = 'forms/temp/f14-temp.xlsx';
	$reader = new PhpOffice\PhpSpreadsheet\Reader\Xlsx;	$objPHPExcel = $reader->load($inputFileName);
	$objPHPExcel->getActiveSheet()->setCellValue('C8','на '.$xP['years'].' учебный год');
	$res1 = DB::$mysqli->query("SELECT * FROM teachers WHERE id_teacher='$id_teacher0'"); $row1=$res1->fetch_assoc();
	$id_chair = $row1['id_chair'];
	$res2 = DB::$mysqli->query("SELECT chair_full FROM chairs WHERE id_chair='$id_chair'"); $row2=$res2->fetch_row();
	$objPHPExcel->getActiveSheet()->setCellValue('A10','Кафедра "'.$row2[0].'"');
	$objPHPExcel->getActiveSheet()->setCellValue('C12',$row1['teacher'].', '.$row1['position'].', '.$row1['title']);
	$stavka = $xP['stavka']; $s = $stavka;
	switch ($stavka){
		case '1': $s = 'ставка'; break;
		case '1/2': $s = 'полставки'; break;
		case '0,75': $s = 'совместительство 0,75 ставки'; break;
		case '0,5': $s = 'совместительство 0,5 ставки'; break;
		case '0,25': $s = 'совместительство 0,25 ставки'; break;
		case 'час': $s = 'почасовая оплата'; break;
	}
	$objPHPExcel->getActiveSheet()->setCellValue('C13','( '.$s.' )');
	$res = DB::$mysqli->query("SELECT * FROM subject WHERE (id_teacher='$id_teacher0' AND stavka='$stavka') OR (id_teacherA='$id_teacher0' AND stavkaA='$stavka')");
	$J_ = []; $J_[1]=21; $J_[2]=64; $J_[3]=107; $J_[4]=128; $J_[11]=148; $J_[12]=191; $J_[13]=234; $J_[14]=257;
	for ($i=0; $row=$res->fetch_assoc(); $i++){
		$grup = $row['grup'];
		$semestr = $row['semestr'];
		$s1 = ((int)mb_substr($xP['years'],2,2) - (int)mb_substr($grup,0,2))*2+1;
		$s2 = ((int)mb_substr($xP['years'],7,2) - (int)mb_substr($grup,0,2))*2;
        if ($s1 != $semestr AND $s2 != $semestr) continue;
		$res1 = DB::$mysqli->query("SELECT level FROM grups WHERE grup='$grup'"); $row1=$res1->fetch_row();
		if ($row['semestr'] % 2 == 0) $J0 = 10; else $J0 = 0;
		switch ($row1[0]){
			case 'Специалитет': $J0 += 1; break;
			case 'Бакалавриат': $J0 += 2; break;
			case 'Магистратура': $J0 += 3; break;
			case 'Аспирантура': $J0 += 4; break;
		}
		$J_[$J0]=$J_[$J0]+2; $J = $J_[$J0];
		$id_subject = $row['id_subject'];
		$res1 = DB::$mysqli->query("SELECT subject FROM subject_n WHERE id_subject='$id_subject'"); $row1=$res1->fetch_row();
		$objPHPExcel->getActiveSheet()->setCellValue('A'.$J,$row1[0]);
		$objPHPExcel->getActiveSheet()->setCellValue('B'.$J,$grup);
		$res1 = DB::$mysqli->query("SELECT * FROM students WHERE grup='$grup'");
		$N0 = 1; $N1 = 0; $N2 = 0; $d0 = strtotime(mb_substr($xP['years'],0,4).'-09-01');
		for ($i1=0; $row1=$res1->fetch_assoc(); $i1++){
			if (strtotime($row1['d0']) > $d0) continue;
			if ($row1['d_out'] != '2000-01-01' AND strtotime($row1['d_out']) < $d0) continue;
			if ($row1['contract'] == 'бюджет') ++$N1; else ++$N2;
			if ($row1['subgrup'] > 1) $N0 = 2;
		}
		if (($N1+$N2) < 1) continue;
		$objPHPExcel->getActiveSheet()->setCellValue('C'.$J,$N0);
		$objPHPExcel->getActiveSheet()->setCellValue('E'.$J,$N1);
		$objPHPExcel->getActiveSheet()->setCellValue('E'.($J+1),$N2);
		$id_teacher = $row['id_teacher']; $x = $row['s_teacher'];
		if ($row['id_teacherA'] == $id_teacher0 AND $row['stavkaA'] == $stavka) $x = $row['s_teacherA'];
		if (in_array($id_subject,[94,95,96,97,98,141,143])){
			$objPHPExcel->getActiveSheet()->setCellValue('AR'.$J,2*($N1+$N2));
		} else {
			if ($x[0] == '1') $s = $row['lections']; else $s = 0; $objPHPExcel->getActiveSheet()->setCellValue('F'.$J,$s);
			if ($x[1] == '1') $s = $row['labworks']; else $s = 0; $objPHPExcel->getActiveSheet()->setCellValue('J'.$J,$s*$N0);
			if ($x[2] == '1') $s = $row['practics']; else $s = 0; $objPHPExcel->getActiveSheet()->setCellValue('H'.$J,$s*$N0);
			if ($row['cw'] > 0 AND $x[3] == '1'){
				$objPHPExcel->getActiveSheet()->setCellValue('N'.$J,2*($N1+$N2));
				$objPHPExcel->getActiveSheet()->setCellValue('X'.$J,0.5*($N1+$N2));
			}	
			if ($row['cp'] > 0 AND $x[4] == '1'){
				$objPHPExcel->getActiveSheet()->setCellValue('N'.$J,3*($N1+$N2));
				$objPHPExcel->getActiveSheet()->setCellValue('X'.$J,0.5*($N1+$N2));
			}	
			if ($row['typefos'] == 'Экзамен' AND $x[5] == '1'){
				$objPHPExcel->getActiveSheet()->setCellValue('R'.$J,1);
				$objPHPExcel->getActiveSheet()->setCellValue('AB'.$J,0.25*($N1+$N2));
			}	
		}	
	}
	for ($i=25; $i<($J_[1]+2); $i++) $objPHPExcel->getActiveSheet()->getRowDimension($i)->setVisible(true);
	for ($i=68; $i<($J_[2]+2); $i++) $objPHPExcel->getActiveSheet()->getRowDimension($i)->setVisible(true);
	for ($i=111; $i<($J_[3]+2); $i++) $objPHPExcel->getActiveSheet()->getRowDimension($i)->setVisible(true);
	for ($i=132; $i<($J_[4]+2); $i++) $objPHPExcel->getActiveSheet()->getRowDimension($i)->setVisible(true);
	for ($i=152; $i<($J_[11]+2); $i++) $objPHPExcel->getActiveSheet()->getRowDimension($i)->setVisible(true);
	for ($i=195; $i<($J_[12]+2); $i++) $objPHPExcel->getActiveSheet()->getRowDimension($i)->setVisible(true);
	for ($i=238; $i<($J_[13]+2); $i++) $objPHPExcel->getActiveSheet()->getRowDimension($i)->setVisible(true);
	for ($i=261; $i<($J_[14]+2); $i++) $objPHPExcel->getActiveSheet()->getRowDimension($i)->setVisible(true);
	$objWriter = new PhpOffice\PhpSpreadsheet\Writer\Xlsx($objPHPExcel);
	$objWriter->save($_SERVER['DOCUMENT_ROOT']."/forms/f14__".$id.".xlsx");
	exit(json_encode(microtime(true)-$time));
}

function f23($id){               # форма 2.3 Список студентов "students"
	$time = microtime(true);
	$inputFileName = 'forms/temp/f23-temp.xlsx';
	$reader = new PhpOffice\PhpSpreadsheet\Reader\Xlsx;	$objPHPExcel = $reader->load($inputFileName);
	$res = DB::$mysqli->query("SELECT * FROM students ORDER BY grup,d_out,contract,student");
	if (!$res) mes("> ".DB::$mysqli->error);
	$J = 3; $n = 0; $g0 = '';
	for ($i=0; $row=$res->fetch_assoc(); $i++){
		$g = $row['grup'];
		if ($g0 != $g){
			$g0 = $g; ++$J; $n = 0;
			$res1 = DB::$mysqli->query("SELECT * FROM grups WHERE grup='$g'"); if (!$res1) mes("> ".DB::$mysqli->error);
			$row1=$res1->fetch_assoc();
			$id_chair = $row1['id_chair'];
			$res2 = DB::$mysqli->query("SELECT * FROM chairs WHERE id_chair='$id_chair'"); if (!$res2) mes("> ".DB::$mysqli->error);
			$row2=$res2->fetch_assoc();
			$s = $g.' кафедра "'.$row2['chair_full'].'", профиль "'.$row1['profile'].'"';
			$objPHPExcel->getActiveSheet()->setCellValue('A'.$J,$s);                                               
			$objPHPExcel->getActiveSheet()->mergeCells('A'.$J.':G'.$J);
			$objPHPExcel->getActiveSheet()->getStyle('A'.$J)->getFont()->setSize(12)->setItalic(true);
		}	
		++$J; ++$n;
		$objPHPExcel->getActiveSheet()->setCellValue('A'.$J,$n);                                               
		$objPHPExcel->getActiveSheet()->setCellValue('B'.$J,$row['student']);
		$objPHPExcel->getActiveSheet()->setCellValue('C'.$J,$row['nbook']);
		$objPHPExcel->getActiveSheet()->setCellValue('D'.$J,$row['contract']);
		$d = db_d($row['d0']); if ($d == '01.01.2000') $d = '';
		$objPHPExcel->getActiveSheet()->setCellValue('E'.$J,$d);
		$d = db_d($row['d_out']); if ($d == '01.01.2000') $d = '';
		$objPHPExcel->getActiveSheet()->setCellValue('F'.$J,$d);;
		$objPHPExcel->getActiveSheet()->setCellValue('G'.$J,$row['session']);
	}
	$objWriter = new PhpOffice\PhpSpreadsheet\Writer\Xlsx($objPHPExcel);
	$objWriter->save($_SERVER['DOCUMENT_ROOT']."/forms/f23__".$id.".xlsx");
	exit(json_encode(microtime(true)-$time));
}
function f26($id){               # форма 2.6 Зачётная книжка студента
	$xP = $_POST['xP'];
	$inputFileName = 'forms/temp/f26-temp.xlsx';
	$reader = new PhpOffice\PhpSpreadsheet\Reader\Xlsx;	$objPHPExcel = $reader->load($inputFileName);
    $student0 = (string)$xP['student'];
	if ($student0 == "") mes(' Нужно задать имя студента! ');
	$semestr0 = (string)$xP['semestr'];
	$objPHPExcel->getActiveSheet()->setCellValue('A1',''.$xP['semestr'].' семестр '.$xP['years'].' учебных годов ');
	$res = DB::$mysqli->query("SELECT sheets.semestr, subject.lections, subject.labworks, subject.practics, subject.control, subject_n.subject, zachetka.mark, zachetka.s_date, teachers.teacher, zachetka.typefos FROM subject_n, zachetka, teachers, students, subject, sheets WHERE subject.id_subject = zachetka.id_subject AND zachetka.s_date = subject.d AND zachetka.id_subject = subject_n.id_subject AND zachetka.id_teacher = teachers.id_teacher AND zachetka.nbook = students.nbook AND zachetka.typefos = 'Экзамен' AND students.student = '$student0' AND subject.semestr = '$semestr0' GROUP BY zachetka.id_subject ORDER BY s_date;");
	$J = 4;
	for ($i=0; $row=$res->fetch_assoc(); $i++){
		//print_r($row); mes('...');
		$subject = $row['subject'];
		$mark = $row['mark'];
		$s_date = $row['s_date'];
		$teacher = $row['teacher'];
		$ar = explode(" ", $teacher); 
		$objPHPExcel->getActiveSheet()->setCellValue('G'.$J,$ar[0]);
		$objPHPExcel->getActiveSheet()->setCellValue('B'.$J,$subject);
		$objPHPExcel->getActiveSheet()->setCellValue('D'.$J,$mark);
		$objPHPExcel->getActiveSheet()->setCellValue('E'.$J,$s_date);
		$r = $row['lections']+$row['labworks']+$row['practics']+$row['control'];
		$h_unit = $r.'/'.round($r/36);
		$objPHPExcel->getActiveSheet()->setCellValue('C'.$J,$h_unit);
		$J = $J+1;
	}	
    $res = DB::$mysqli->query("SELECT sheets.semestr, subject.lections, subject.labworks, subject.practics, subject.control, subject_n.subject, zachetka.mark, zachetka.s_date, teachers.teacher, zachetka.typefos FROM subject_n, zachetka, teachers, students, subject, sheets WHERE subject.id_subject = zachetka.id_subject AND zachetka.s_date = subject.d AND zachetka.id_subject = subject_n.id_subject AND zachetka.id_teacher = teachers.id_teacher AND zachetka.nbook = students.nbook AND (zachetka.typefos = 'Зачёт' OR zachetka.typefos = 'Зачёт с оценкой') AND students.student = '$student0' AND subject.semestr = '$semestr0' GROUP BY zachetka.id_subject ORDER BY s_date;");
	$J = 17;	
	for ($i=0; $row=$res->fetch_assoc(); $i++){
		//print_r($row); mes('...');
		$subject = $row['subject'];
		$mark = $row['mark'];
		$s_date = $row['s_date'];
		$teacher = $row['teacher'];
		
		$ar = explode(" ", $teacher); 
		$objPHPExcel->getActiveSheet()->setCellValue('G'.$J,$ar[0]);
		$objPHPExcel->getActiveSheet()->setCellValue('B'.$J,$subject);
		$objPHPExcel->getActiveSheet()->setCellValue('D'.$J,$mark);
		$objPHPExcel->getActiveSheet()->setCellValue('E'.$J,$s_date);
		$r = $row['lections']+$row['labworks']+$row['practics']+$row['control'];
		$h_unit = $r.'/'.round($r/36);
		$objPHPExcel->getActiveSheet()->setCellValue('C'.$J,$h_unit);
		$J = $J+1;
	}

	/*
	for ($i=25; $i<($J_[1]+2); $i++) $objPHPExcel->getActiveSheet()->getRowDimension($i)->setVisible(true);
	for ($i=68; $i<($J_[2]+2); $i++) $objPHPExcel->getActiveSheet()->getRowDimension($i)->setVisible(true);
	for ($i=111; $i<($J_[3]+2); $i++) $objPHPExcel->getActiveSheet()->getRowDimension($i)->setVisible(true);
	for ($i=132; $i<($J_[4]+2); $i++) $objPHPExcel->getActiveSheet()->getRowDimension($i)->setVisible(true);
	for ($i=152; $i<($J_[11]+2); $i++) $objPHPExcel->getActiveSheet()->getRowDimension($i)->setVisible(true);
	for ($i=195; $i<($J_[12]+2); $i++) $objPHPExcel->getActiveSheet()->getRowDimension($i)->setVisible(true);
	for ($i=238; $i<($J_[13]+2); $i++) $objPHPExcel->getActiveSheet()->getRowDimension($i)->setVisible(true);
	for ($i=261; $i<($J_[14]+2); $i++) $objPHPExcel->getActiveSheet()->getRowDimension($i)->setVisible(true);
	*/
	$objWriter = new PhpOffice\PhpSpreadsheet\Writer\Xlsx($objPHPExcel);
	$objWriter->save($_SERVER['DOCUMENT_ROOT']."/forms/f26__".$id.".xlsx");
	exit(json_encode(microtime(true)-$time));
}

function searchLogin(){          # Получение списка пользователей ИС
	$list = []; $s = $_POST['s']; 
	$res = DB::$mysqli->query("SELECT DISTINCT login FROM users WHERE (login LIKE '%$s%') ORDER BY login LIMIT 0,35");
	for ($i=0; $row=$res->fetch_row(); $i++) $list[$i] = $row[0];
	exit(json_encode($list));
}	
function searchChair(){          # Получение списка кафедр
	$list = []; $s = $_POST['s'];  
	$res = DB::$mysqli->query("SELECT * FROM chairs WHERE id_chair LIKE '%$s%' OR chair LIKE '%$s%' ORDER BY chair LIMIT 0,15");
	for ($i=0; $row=$res->fetch_assoc(); $i++) $list[$i] = $row['chair'].' <i>кафедра</i> "'.$row['chair_full'].'", <i>код</i> '.$row['id_chair'];
	exit(json_encode($list));
}	
function searchIdChair(){        # Получение списка кодов кафедр
	$list = []; $s = $_POST['s'];  
	$res = DB::$mysqli->query("SELECT id_chair FROM chairs WHERE id_chair LIKE '%$s%' ORDER BY id_chair DESC LIMIT 0,15");
	for ($i=0; $row=$res->fetch_row(); $i++) $list[$i] = $row[0];
	exit(json_encode($list));
}	
function searchChairFull(){      # Получение списка полных наименований кафедр
	$list = []; $s = $_POST['s'];  
	$res = DB::$mysqli->query("SELECT chair_full FROM chairs WHERE chair_full LIKE '%$s%' ORDER BY chair_full DESC LIMIT 0,15");
	for ($i=0; $row=$res->fetch_row(); $i++) $list[$i] = $row[0];
	exit(json_encode($list));
}	
function searchGrup(){           # Получение списка груп
	$list = []; $s = $_POST['s'];  
	$res = DB::$mysqli->query("SELECT * FROM grups WHERE grup LIKE '%$s%' ORDER BY grup LIMIT 0,15");
	for ($i=0; $row=$res->fetch_assoc(); $i++){
		$id = $row['id_chair'];
		$res1 = DB::$mysqli->query("SELECT chair FROM chairs WHERE id_chair='$id'"); $row1 = $res1->fetch_row();
		$list[$i] = $row['grup'].' <i>кафедра '.$row1[0].', шифр:</i>'.$row['cypher'].'<i> '.$row['profile'].'</i>';
	}	
	exit(json_encode($list));
}	
function searchCypher(){         # Получение списка шифров специальностей
	$list = []; $s = $_POST['s'];  
	$res = DB::$mysqli->query("SELECT DISTINCT cypher FROM grups WHERE cypher LIKE '%$s%' ORDER BY cypher LIMIT 0,15");
	for ($i=0; $row=$res->fetch_row(); $i++) $list[$i] = $row[0];
	exit(json_encode($list));
}	
function searchSpecialization(){ # Получение списка направлений
	$list = []; $s = $_POST['s'];  
	$res = DB::$mysqli->query("SELECT DISTINCT specialization FROM grups WHERE specialization LIKE '%$s%' ORDER BY Specialization LIMIT 0,15");
	for ($i=0; $row=$res->fetch_row(); $i++) $list[$i] = $row[0];
	exit(json_encode($list));
}	
function searchProfile(){        # Получение списка профилей
	$list = []; $s = $_POST['s'];  
	$res = DB::$mysqli->query("SELECT DISTINCT profile FROM grups WHERE profile LIKE '%$s%' ORDER BY profile LIMIT 0,15");
	for ($i=0; $row=$res->fetch_row(); $i++) $list[$i] = $row[0];
	exit(json_encode($list));
}	
function searchStudent(){        # Получение списка студентов
	$list = []; $s = $_POST['s'];  
	$res = DB::$mysqli->query("SELECT * FROM students WHERE student LIKE '%$s%' ORDER BY student LIMIT 0,15");
	for ($i=0; $row=$res->fetch_assoc(); $i++) $list[$i] = $row['student'].' <i> группа '.$row['grup'].', №</i>'.$row['nbook'];
	exit(json_encode($list));
}	
function searchNbook(){          # Получение списка номеров зачетных книжек
	$list = []; $s = $_POST['s'];  
	$res = DB::$mysqli->query("SELECT DISTINCT nbook FROM students WHERE nbook LIKE '%$s%' ORDER BY nbook LIMIT 0,15");
	for ($i=0; $row=$res->fetch_row(); $i++) $list[$i] = $row[0];
	exit(json_encode($list));
}	
function searchTeacher(){        # Получение списка преподавателей
	$list = []; $s = $_POST['s'];  
	$res = DB::$mysqli->query("SELECT * FROM teachers WHERE teacher LIKE '%$s%' ORDER BY teacher LIMIT 0,15");
	for ($i=0; $row=$res->fetch_assoc(); $i++){
		$id_chair = $row['id_chair'];
		$res1 = DB::$mysqli->query("SELECT chair FROM chairs WHERE id_chair='$id_chair'"); $row1 = $res1->fetch_row();
		$list[$i] = $row['teacher'].' <i>('.$row['id_teacher'].') кафедра '.$row1[0].' ('.$id_chair.'), '.$row['position'].'</i>';
	}	
	exit(json_encode($list));
}	
function searchIdTeacher(){      # Получение списка кодов преподавателей
	$list = []; $s = $_POST['s'];  
	$res = DB::$mysqli->query("SELECT id_teacher FROM teachers WHERE id_teacher LIKE '%$s%' ORDER BY id_teacher DESC LIMIT 0,15");
	for ($i=0; $row=$res->fetch_row(); $i++) $list[$i] = $row[0];
	exit(json_encode($list));
}	
function searchPosition(){       # Получение списка должностей
	$list = []; $s = $_POST['s'];  
	$res = DB::$mysqli->query("SELECT DISTINCT position FROM teachers WHERE position LIKE '%$s%' ORDER BY position LIMIT 0,15");
	for ($i=0; $row=$res->fetch_row(); $i++) $list[$i] = $row[0];
	exit(json_encode($list));
}	
function searchTitle(){          # Получение списка ученых званий
	$list = []; $s = $_POST['s'];  
	$res = DB::$mysqli->query("SELECT DISTINCT title FROM teachers WHERE title LIKE '%$s%' ORDER BY title LIMIT 0,15");
	for ($i=0; $row=$res->fetch_row(); $i++) $list[$i] = $row[0];
	exit(json_encode($list));
}	
function searchDegree(){         # Получение списка ученых степеней
	$list = []; $s = $_POST['s'];  
	$res = DB::$mysqli->query("SELECT DISTINCT degree FROM teachers WHERE degree LIKE '%$s%' ORDER BY degree LIMIT 0,15");
	for ($i=0; $row=$res->fetch_row(); $i++) $list[$i] = $row[0];
	exit(json_encode($list));
}	
function searchSubject(){        # Получение списка дисциплин
	$list = []; $s = $_POST['s'];  
	$res = DB::$mysqli->query("SELECT * FROM subjects WHERE subject LIKE '%$s%' ORDER BY subject LIMIT 0,15");
	for ($i=0; $row=$res->fetch_assoc(); $i++) $list[$i] = $row['subject'].' <i>('.$row['id_subject'].')</i>';
	exit(json_encode($list));
}	
function searchIdSubject(){      # Получение списка кодов дисциплин
	$list = []; $s = $_POST['s'];  
	$res = DB::$mysqli->query("SELECT id_subject FROM subjects WHERE id_subject LIKE '%$s%' ORDER BY id_subject DESC LIMIT 0,15");
	for ($i=0; $row=$res->fetch_row(); $i++) $list[$i] = $row[0];
	exit(json_encode($list));
}	

function readChr(){              # Чтение данных индивидуального плана
	$xD = $_POST['xD'];  
	$xP = $_POST['xP'];  
	$year = (int)mb_substr($xP['years'],0,4);
	$grup0 = $xP['grup'];  
	$id_subject0 = $xP['id_subject'];  
	$id_teacher0 = $xP['id_teacher'];
	$id_chair0 = $xP['id_chair'];  
	$stavka0 = $xP['stavka'];  
	$query = "SELECT * FROM catalog WHERE d>='2000-01-01'"; 
	if ($grup0 != '') $query .= " AND grup='$grup0'";
	if ($id_subject0 > 0) $query .= " AND id_subject='$id_subject0'";
	$res = DB::$mysqli->query($query); if (!$res) mes("> ".DB::$mysqli->error);
	$j = -1; $S = [];
	for ($i=0; $row=$res->fetch_assoc(); $i++){
		$grup = $row['grup'];
		$semestr = $row['semestr'];
		// проверка семестра
		$s1 = ((int)mb_substr($xP['years'],2,2) - (int)mb_substr($grup,0,2))*2+1;
		$s2 = ((int)mb_substr($xP['years'],7,2) - (int)mb_substr($grup,0,2))*2;
        if ($s1 != $semestr AND $s2 != $semestr) continue;
		$id_subject = $row['id_subject'];
		// проверка кафедры
		if ($id_chair0 > 0){
			$res1 = DB::$mysqli->query("SELECT id_chair FROM catalog_h WHERE grup='$grup' AND id_subject='$id_subject'"); $row1 = $res1->fetch_row();
			if ($id_chair0 != $row1[0]) continue;
		}	
		$id_teacher = $row['id_teacher'];
		$s_teacher = $row['s_teacher'];
		$stavka = $row['stavka'];
		$id_teacherA = $row['id_teacherA'];
		$s_teacherA = $row['s_teacherA'];
		$stavkaA = $row['stavkaA'];
		$tf_s = false; 
		if ($id_teacher > 0){
			$tf_s = true;
			for ($k=0; $k < 6; $k++){
				switch ($k){
					case 0: $x = $row['lections']; break;
					case 1: $x = $row['labworks']; break;
					case 2: $x = $row['practics']; break;
					case 3: $x = $row['cw']; break;
					case 4: $x = $row['cp']; break;
					case 5: $x = 1; break;
				}
				if ($x > 0 AND $s_teacher[$k] == '0' AND $s_teacherA[$k] == '0') $tf_s = false;
			}
		}
		if ($id_teacher0 == 0){if ($tf_s AND $xP['p_chr'] == 0) continue;} else {
			if ($id_teacher > 0){
				if ($tf_s){
					$tf = true;
					if ($id_teacher0 == $id_teacher) if ($stavka0 == '' OR ($stavka0 != '' AND $stavka0 == $stavka)) $tf = false;
					if ($id_teacher0 == $id_teacherA) if ($stavka0 == '' OR ($stavka0 != '' AND $stavka0 == $stavkaA)) $tf = false;
					if ($tf) continue;
				}

			}			
		}
		// озвучка предмета
		$res1 = DB::$mysqli->query("SELECT subject FROM subjects WHERE id_subject='$id_subject'"); $row1 = $res1->fetch_row();
		// озвучка преподавателя и ассистента
		if ($id_teacher > 0){
			$res2 = DB::$mysqli->query("SELECT teacher FROM teachers WHERE id_teacher='$id_teacher'"); $row2 = $res2->fetch_row();
			$teacher = $row2[0];
		} else $teacher = '';	
		$id_teacherA = $row['id_teacherA'];
		if ($id_teacherA > 0){
			$res2 = DB::$mysqli->query("SELECT teacher FROM teachers WHERE id_teacher='$id_teacherA'"); $row2 = $res2->fetch_row();
			$teacherA = $row2[0];
		} else $teacherA = '';	
		// подсчет студентов
		$res3 = DB::$mysqli->query("SELECT * FROM students WHERE grup='$grup'");
		$N0 = 1; $N1 = 0; $N2 = 0; $d0 = strtotime(mb_substr($xP['years'],0,4).'-09-01');
		for ($i1=0; $row3=$res3->fetch_assoc(); $i1++){
			if (strtotime($row3['d0']) > $d0) continue;
			if ($row3['d_out'] != '2000-01-01' AND strtotime($row3['d_out']) < $d0) continue;
			if ($row3['contract'] == 'бюджет') ++$N1; else ++$N2;
			if ($row3['subgrup'] > 1) $N0 = 2;
		}
		++$j; $S[$j] = ['grup'=>$row['grup'],'id_subject'=>$id_subject,'subject'=>$row1[0],'semestr'=>$semestr,'N0'=>$N0,'N1'=>$N1,'N2'=>$N2,
		'lections'=>$row['lections'],'labworks'=>$row['labworks'],'practics'=>$row['practics'],'cw'=>$row['cw'],'cp'=>$row['cp'],'typefos'=>$row['typefos'],
		'id_teacher'=>$id_teacher,'teacher'=>$teacher,'s_teacher'=>$s_teacher,'stavka'=>$stavka,
		'id_teacherA'=>$id_teacherA,'teacherA'=>$teacherA,'s_teacherA'=>$s_teacherA,'stavkaA'=>$stavkaA,
		'control'=>$row['control']];
	}	
//echo ' >'.$id_teacher0.'|'.$id_teacher.'/'.$tf_.'/';
//mes(' ...'.$j);	
	exit(json_encode($S));
}	
function writeChr(){             # Запись данных индивидуального плана
	$Chr = $_POST['Chr'];  
	foreach($Chr as $j => $a){
		$grup = $a['grup'];
		$id_subject = $a['id_subject'];
		$semestr = $a['semestr'];
		$id_teacher = (int)$a['id_teacher'];
		$s_teacher = $a['s_teacher'];
		$stavka = $a['stavka'];
		$id_teacherA = (int)$a['id_teacherA'];
		$s_teacherA = $a['s_teacherA'];
		$stavkaA = $a['stavkaA'];
		if ($id_teacher == 0){$s_teacher = '000000'; $stavka = '';}
		if ($id_teacherA == 0){$s_teacherA = '000000'; $stavkaA = '';}
		for ($i=0; $i<6; $i++) if ($s_teacher[$i] != '0') $s_teacherA[$i] = '0';
		if (($s_teacher[0] == '0' AND $s_teacherA[0] == '1') OR ($id_teacher == 0 AND $id_teacherA > 0)){
			$id_ = $id_teacher; $s_ = $s_teacher; $s_t = $stavka;
			$id_teacher = $id_teacherA; $s_teacher = $s_teacherA; $stavka = $stavka0;
			$id_teacherA = $id_; $s_teacherA = $s_; $stavkaA = $s_t;
		}	
		if ($id_teacher > 0 AND $stavka == '') $stavka = '1';
		if ($id_teacherA > 0 AND $stavkaA == '') $stavkaA = '1';
		$res = DB::$mysqli->query("UPDATE catalog SET id_teacher='$id_teacher',s_teacher='$s_teacher',stavka='$stavka',
			id_teacherA='$id_teacherA',s_teacherA='$s_teacherA',stavkaA='$stavkaA'
			WHERE grup='$grup' AND id_subject='$id_subject' AND semestr='$semestr'");
		if (!$res) mes("> ".DB::$mysqli->error);
	}	
	exit(json_encode('+'));
}
function readDek(){              # Чтение данных деканата
	$xD = $_POST['xD'];  
	$xP = $_POST['xP'];  
	$id_chair0 = $xP['id_chair'];  
	$grup0 = $xP['grup'];  
	$id_subject0 = $xP['id_subject'];  
	$id_teacher0 = $xP['id_teacher'];
	$query = "SELECT * FROM catalog WHERE d>='2000-01-01'"; 
	if ($grup0 != '') $query .= " AND grup='$grup0'";
	if ($id_subject0 > 0) $query .= " AND id_subject='$id_subject0'";
	if ($id_teacher0 > 0) $query .= " AND id_teacher='$id_teacher0' ORDER BY id_teacher DESC,id_teacherA DESC,grup,semestr,typefos"; else $query .= " ORDER BY grup,semestr,typefos";
	$res = DB::$mysqli->query($query); if (!$res) mes("> ".DB::$mysqli->error);
	$j = -1; $S = [];
	for ($i=0; $row=$res->fetch_assoc(); $i++){
		$grup = $row['grup'];
		$id_subject = $row['id_subject'];
		$id_teacher = $row['id_teacher'];
		$semestr = $row['semestr'];
		$s1 = ((int)mb_substr($xP['years'],2,2) - (int)mb_substr($grup,0,2))*2+1;
		$s2 = ((int)mb_substr($xP['years'],7,2) - (int)mb_substr($grup,0,2))*2;
        if ($s1 != $semestr AND $s2 != $semestr) continue;
		if ($id_chair0 > 0){
			$res1 = DB::$mysqli->query("SELECT id_chair FROM catalog_h WHERE grup='$grup' AND id_subject='$id_subject'"); $row1 = $res1->fetch_row();
			if ($id_chair0 != $row1[0]) continue;
		}	
		$curs = (int)mb_substr($xD,8,2) - (int)mb_substr($grup,0,2);
		$m = (int)mb_substr($xD,3,2); if ($m >= 8) ++$curs;
		$res1 = DB::$mysqli->query("SELECT subject FROM subjects WHERE id_subject='$id_subject'"); $row1 = $res1->fetch_row();
		$res2 = DB::$mysqli->query("SELECT teacher FROM teachers WHERE id_teacher='$id_teacher'"); $row2 = $res2->fetch_row();
		$r = $row['lections']+$row['labworks']+$row['practics']+$row['control'];
		$h_unit = $r.'/'.round($r/36);
		++$j; $S[$j] = ['grup'=>$row['grup'],'id_subject'=>$id_subject,'subject'=>$row1[0],
			'semestr'=>$semestr,'curs'=>$curs,'h_unit'=>$h_unit,'typefos'=>$row['typefos'],
			'id_teacher'=>$id_teacher,'teacher'=>$row2[0],'d'=>db_d($row['d']),'N'=>$row['N']];
	}	
	exit(json_encode($S));
}	
function writeDek(){             # Запись данных деканата
	$Dek = $_POST['Dek'];  
	foreach($Dek as $j => $a){
		$grup = $a['grup'];
		$id_subject = $a['id_subject'];
		$semestr = $a['semestr'];
		$d = d_db($a['d']);
		$N = (int)$a['N'];
		$res = DB::$mysqli->query("UPDATE catalog SET d='$d',N='$N' WHERE grup='$grup' AND id_subject='$id_subject' AND semestr='$semestr'");
		if (!$res) mes("> ".DB::$mysqli->error);
	}	
	exit(json_encode('+'));
}
function readRep(){              # Чтение данных учебного плана
	$xP = $_POST['xP'];  
	$grup = $xP['grup'];  
	$j = -1; $S = [];
	$res = DB::$mysqli->query("SELECT * FROM catalog_h WHERE grup='$grup' ORDER BY I");
	for ($i=0; $row=$res->fetch_assoc(); $i++){
		$id_subject = $row['id_subject'];
		$res1 = DB::$mysqli->query("SELECT subject FROM subjects WHERE id_subject='$id_subject'");
		$row1 = $res1->fetch_row();
		$res2 = DB::$mysqli->query("SELECT * FROM catalog WHERE grup='$grup' AND id_subject='$id_subject' ORDER BY semestr");
		for ($i2=0; $row2=$res2->fetch_assoc(); $i2++){
			++$j; $S[$j] = $row2; 
			$S[$j]['subject'] = $row1[0];
			$S[$j]['I'] = $row['I'];
			$S[$j]['A'] = $row['A'];
			$S[$j]['B'] = $row['B'];
			$S[$j]['id_chair'] = $row['id_chair'];
			$S[$j]['competentions'] = $row['competentions'];
			$S[$j]['d'] = db_d($row2['d']); 
		}
	}	
	exit(json_encode($S));
}
function writeRep(){             # Запись данных учебного плана
	$xP = $_POST['xP'];  
	$grup = $xP['grup'];
	$Rep = $_POST['Rep'];  
	if ($Rep[0]['grup'] != $grup) mes('Ошибка в коде группы <b>'.$grup.'</b>...');
	$fields = $type = [];	$res = DB::$mysqli->query("SHOW COLUMNS FROM catalog_h"); // массив полей таблицы catalog_h
	while ($r = $res->fetch_assoc()){$fields[] = $r['Field']; $type[] = $r['Type'];}
	$len = count($fields);
	DB::$mysqli->query("DELETE FROM catalog_h WHERE grup='$grup'");
	foreach($Rep as $j => $a){if ($a['id_subject'] > 0){ // ввод новых записей в таблицу catalog_h
		$id_subject = $a['id_subject'];
		$res = DB::$mysqli->query("SELECT grup FROM catalog_h WHERE grup='$grup' AND id_subject='$id_subject'");
		$row=$res->fetch_row();	if ($row[0]) continue;
		$s = 'grup'; $v = "'".$grup."'"; 
		for ($i=1; $i<$len; $i++){$s .= ",".$fields[$i]; $v0 = db($type[$i],$a[$fields[$i]]); $v .= ",'".$v0."'";}
		$res = DB::$mysqli->query ("INSERT INTO catalog_h ($s) VALUES($v)");
		if (!$res) mes('Ошибка, запись новых данных в <b>catalog_h</b> не выполнена!');
	}}
	$fields = $type = [];	$res = DB::$mysqli->query("SHOW COLUMNS FROM catalog"); // массив полей таблицы catalog
	while ($r = $res->fetch_assoc()){$fields[] = $r['Field']; $type[] = $r['Type'];}
	$len = count($fields);
	DB::$mysqli->query("DELETE FROM catalog WHERE grup='$grup'");
	foreach($Rep as $j => $a){if ($a['id_subject'] > 0 AND $a['semestr'] > 0){ // ввод новых записей в таблицу catalog
		$id_subject = $a['id_subject'];
		$semestr = $a['semestr'];
		$res = DB::$mysqli->query("SELECT grup FROM catalog WHERE grup='$grup' AND id_subject='$id_subject' AND semestr='$semestr'");
		$row = $res->fetch_row(); if ($row[0]) continue;
		$s = 'grup'; $v = "'".$grup."'"; 
		for ($i=1; $i<$len; $i++){$s .= ",".$fields[$i]; $v0 = db($type[$i],$a[$fields[$i]]); $v .= ",'".$v0."'";}
		$res = DB::$mysqli->query ("INSERT INTO catalog ($s) VALUES($v)");
		if (!$res) mes('Ошибка, запись новых данных <b>catalog</b> не выпонена !');
	}}
	exit(json_encode('+'));
}
function readSheetV(){           # Чтение данных заголовка ведомости
	$xP = $_POST['xP'];  
	$grup = $xP['grup'];  
	$id_subject = $xP['id_subject'];  
	$semestr = $xP['semestr'];  
	$V = ['h_unit'=>'','typefos'=>'','teacher'=>'','d'=>'','N'=>''];
	$res = DB::$mysqli->query("SELECT d FROM catalog WHERE grup='$grup' AND id_subject='$id_subject'"); if (!$res) mes("> ".DB::$mysqli->error);
	$row = $res->fetch_assoc();	if (!$row['d']){$V['d'] = '*'; exit(json_encode($V));}
	$res = DB::$mysqli->query("SELECT * FROM catalog WHERE grup='$grup' AND id_subject='$id_subject' AND semestr='$semestr'"); if (!$res) mes("> ".DB::$mysqli->error);
	$row = $res->fetch_assoc();
	if ($row['d']){
		$r = $row['lections']+$row['labworks']+$row['practics']+$row['control'];
		$V['h_unit'] = $r.'/'.round($r/36);
		$V['typefos'] = $row['typefos'];
		$id_teacher = $row['id_teacher'];
		$V['id_teacher'] = $id_teacher;
		$res1 = DB::$mysqli->query("SELECT teacher FROM teachers WHERE id_teacher='$id_teacher'"); if (!$res) mes("> ".DB::$mysqli->error);
		$row1 = $res1->fetch_row();
		$V['teacher'] = $row1[0];
		if ($row['d'] != '2000-01-01') $V['d'] = db_d($row['d']); else $V['d'] = '';
		$V['N'] = $row['N'];
		$V['tch'] = $row['tch'];
		$V['dek'] = $row['dek'];
	} else $V['d'] = '**';	
	exit(json_encode($V));
}	
function readSheet(){            # Чтение данных о студентах для ведомости
	$xP = $_POST['xP'];  
	$grup = $xP['grup'];  
	$id_subject = $xP['id_subject'];  
	$semestr = $xP['semestr'];  
	$res = DB::$mysqli->query("SELECT * FROM students WHERE grup='$grup' AND d_out='2000-01-01' ORDER BY student"); if (!$res) mes("> ".DB::$mysqli->error);
	$S = [];
	for ($i=0; $row=$res->fetch_assoc(); $i++){
		$S[$i] = []; $S[$i]['nbook'] = $row['nbook']; $S[$i]['student'] = $row['student']; $S[$i]['est'] = $row['session'];
	}	
	$res = DB::$mysqli->query("SELECT nbook,est FROM sheets WHERE grup='$grup' AND id_subject='$id_subject' AND semestr='$semestr'"); if (!$res) mes("> ".DB::$mysqli->error);
	for ($i=0; $row=$res->fetch_row(); $i++){
		$nbook = $row[0];
		$est = $row[1];
		if ($est != '' OR $est == 'не допущен'){
			for ($k=0; $k<count($S); $k++) if ($S[$k]['nbook']==$nbook) break;
			if ($k == count($S)){
				$res1 = DB::$mysqli->query("SELECT student FROM students WHERE nbook='$nbook'"); if (!$res) mes("> ".DB::$mysqli->error);
				$row1 = $res1->fetch_row();
				$S[] = ['nbook'=>$nbook,'student'=>$row1[0],'est'=>$est];
			} else $S[$k]['est'] = $est;
		}
	}
	exit(json_encode($S));
}	
function writeSheet(){           # Запись данных ведомости
	$xP = $_POST['xP'];  
	$grup = $xP['grup'];  
	$id_subject = $xP['id_subject'];  
	$semestr = $xP['semestr'];  
	$res = DB::$mysqli->query("SELECT d FROM catalog WHERE grup='$grup' AND id_subject='$id_subject' AND semestr='$semestr'"); if (!$res) mes("> ".DB::$mysqli->error);
	$row = $res->fetch_row();
	if (!$row[0]) exit(json_encode('-'));
	DB::$mysqli->query("DELETE FROM sheets WHERE grup='$grup' AND id_subject='$id_subject' AND semestr='$semestr'");
	$Sheet = $_POST['Sheet'];  
	for ($i=0; $i<count($Sheet); $i++){
		$nbook = (int)$Sheet[$i]['nbook'];
		$est = $Sheet[$i]['est'];
		$res = DB::$mysqli->query("INSERT INTO sheets (grup,id_subject,semestr,nbook,est) VALUES ('$grup','$id_subject','$semestr','$nbook','$est')");
		if (!$res) mes("> ".DB::$mysqli->error);
	}	
	$xV = $_POST['xV'];  
	$tch = $xV['tch']; DB::$mysqli->query("UPDATE catalog SET tch='$tch' WHERE grup='$grup' AND id_subject='$id_subject' AND semestr='$semestr'");  
	$dek = $xV['dek']; DB::$mysqli->query("UPDATE catalog SET dek='$dek' WHERE grup='$grup' AND id_subject='$id_subject' AND semestr='$semestr'");  
	exit(json_encode('+'));
}	

function readChair(){            # Чтение параметров кафедры по группе
	$a = []; $a['id_chair'] = 0; $a['chair'] = '';
	$grup = $_POST['grup'];  
	$res = DB::$mysqli->query("SELECT id_chair FROM grups WHERE grup='$grup'");
	if (!$res) mes("> ".DB::$mysqli->error); $row=$res->fetch_row();
	if ($row[0]){
		$a['id_chair'] = $row[0];
		$res = DB::$mysqli->query("SELECT chair FROM chairs WHERE id_chair='$row[0]'");
		if (!$res) mes("> ".DB::$mysqli->error); $row=$res->fetch_row();
		if ($row[0]) $a['chair'] = $row[0];
	}
	exit(json_encode($a));
}	
function readRef(){              # Чтение записи справочника из БД
	$nameRef = $_POST['nameRef']; 
	$id = $_POST['id']; 
	switch ($nameRef){
		case 'chair': $res = DB::$mysqli->query("SELECT * FROM chairs WHERE id_chair='$id'"); break;
		case 'grup': $res = DB::$mysqli->query("SELECT * FROM grups WHERE grup='$id'"); break;
		case 'student': $res = DB::$mysqli->query("SELECT * FROM students WHERE nbook='$id'"); break;
		case 'teacher': $res = DB::$mysqli->query("SELECT * FROM teachers WHERE id_teacher='$id'"); break;
		case 'subject': $res = DB::$mysqli->query("SELECT * FROM subjects WHERE id_subject='$id'"); break;
	}
	if (!$res) mes("> ".DB::$mysqli->error); $row=$res->fetch_assoc();
	if ($nameRef == 'grup' OR $nameRef == 'teacher'){
		$id = $row['id_chair'];
		$res1 = DB::$mysqli->query("SELECT chair FROM chairs WHERE id_chair='$id'");
		if (!$res) mes("> ".DB::$mysqli->error); $row1=$res1->fetch_row();
		$row['chair'] = $row1[0];
	}
	if ($nameRef == 'student'){
		if ($row['d0'] == '2000-01-01') $row['d0'] = ''; else $row['d0'] = db_d($row['d0']);
		if ($row['d_out'] == '2000-01-01') $row['d_out'] = ''; else $row['d_out'] = db_d($row['d_out']);
	}
	exit(json_encode($row));
}
function Ref(){                  # Чтение (запись,удаление строк) справочников
	$user = access(); $id_user = $user['id'];
	$p = $_POST['p']; 
	$nameRef = $_POST['nameRef'];
	$r = $_POST['ref_'];
	$s = '';
	switch ($p){
		case 'write':
			switch ($nameRef){
				case 'chair':
					$id_chair = $r['id_chair'];
					$chair = $r['chair'];
					$chair_full = $r['chair_full'];
					DB::$mysqli->query("DELETE FROM chairs WHERE id_chair='$id_chair'");
					$res = DB::$mysqli->query("INSERT INTO chairs (id_chair,chair,chair_full) VALUES ('$id_chair','$chair','$chair_full')");
					if (!$res) mes("> ".DB::$mysqli->error);
					$s = 'данные кафедры <b>'.$chair.' ('.$id_chair.')</b> внесены в справочник <b>кафедры</b> (chairs)';
				break;
				case 'grup':
					$grup = $r['grup'];
					$id_chair = $r['id_chair'];
					$level = $r['level'];
					$ofo = $r['ofo'];
					$cypher = $r['cypher'];
					$specialization = $r['specialization'];
					$profile = $r['profile'];
					DB::$mysqli->query("DELETE FROM grups WHERE grup='$grup'");
					$res = DB::$mysqli->query("INSERT INTO grups (grup,id_chair,level,ofo,cypher,specialization,profile)
						VALUES ('$grup','$id_chair','$level','$ofo','$cypher','$specialization','$profile')");
					if (!$res) mes("> ".DB::$mysqli->error);
					$s = 'Данные группы <b>'.$grup.'</b> внесены в справочник <b>группы</b> (grups)';
				break;
				case 'student':
					$nbook = $r['nbook'];
					$student = $r['student'];
					$grup = $r['grup'];
					$subgrup = $r['subgrup'];
					$contract = $r['contract'];
					$d0 = ($r['d0']); if ($d0 == '') $d0 = '2000-01-01'; else $d0 = d_db($d0);
					$d_out = ($r['d_out']); if ($d_out == '') $d_out = '2000-01-01'; else $d_out = d_db($d_out);
					$session = $r['session'];
//mes($d0.' '.$d_out.' '.$session);
					DB::$mysqli->query("DELETE FROM students WHERE nbook='$nbook'");
					$res = DB::$mysqli->query("INSERT INTO students (nbook,student,grup,subgrup,contract,d0,d_out,session)
						VALUES ('$nbook','$student','$grup','$subgrup','$contract','$d0','$d_out','$session')");
					if (!$res) mes("> ".DB::$mysqli->error);
					$s = 'Данные студента <b>'.$student.' ('.$nbook.')</b> внесены в справочник <b>студенты</b> (students)';
				break;
				case 'teacher':
					$id_teacher = $r['id_teacher'];
					$teacher = $r['teacher'];
					$id_chair = $r['id_chair'];
					$position = $r['position'];
					$title = $r['title'];
					$degree = $r['degree'];
					if ($id_teacher > 0){
						DB::$mysqli->query("DELETE FROM teachers WHERE id_teacher='$id_teacher'");
						$res = DB::$mysqli->query("INSERT INTO teachers (id_teacher,teacher,id_chair,position,title,degree)
						VALUES ('$id_teacher','$teacher','$id_chair','$position','$title','$degree')");
					} else $res = DB::$mysqli->query("INSERT INTO teachers (teacher,id_chair,position,title,degree)
						VALUES ('$teacher','$id_chair','$position','$title','$degree')");
					if (!$res) mes("> ".DB::$mysqli->error);
					$s = 'Данные преподавателя <b>'.$teacher.' ('.$id_teacher.')</b> внесены в справочник <b>преподаватели</b> (teachers)';
				break;
				case 'subject':
					$id_subject = $r['id_subject'];
					$subject = $r['subject'];
					if ($id_subject > 0){
						DB::$mysqli->query("DELETE FROM subjects WHERE id_subject='$id_subject'");
						$res = DB::$mysqli->query("INSERT INTO subjects (id_subject,subject) VALUES ('$id_subject','$subject')");
					} else $res = DB::$mysqli->query("INSERT INTO subjects (subject) VALUES ('$subject')");
					if (!$res) mes("> ".DB::$mysqli->error);
					$s = 'Данные дисциплины <b>'.$subject.' ('.$id_subject.')</b> внесены в справочник <b>дисциплины</b> (subjects)';
				break;
			}
		break;	
		case 'del':
			switch ($nameRef){
				case 'chair':
					$id_chair = $r['id_chair'];
					$chair = $r['chair'];
					DB::$mysqli->query("DELETE FROM chairs WHERE id_chair='$id_chair'");
					$s = 'Данные кафедры <b>'.$chair.' ('.$id_chair.')</b> удалены из справочника <b>кафедры</b> (chairs)';
				break;
				case 'grup':
					$grup = $r['grup'];
					DB::$mysqli->query("DELETE FROM grups WHERE grup='$grup'");
					$s = 'Данные группы <b>'.$grup.'</b> удалены из справочника <b>группы</b> (grups)';
				break;
				case 'student':
					$nbook = $r['nbook'];
					$student = $r['student'];
					DB::$mysqli->query("DELETE FROM students WHERE nbook='$nbook'");
					$s = 'Данные студента <b>'.$student.' ('.$nbook.')</b> удалены из справочника <b>студенты</b> (students)';
				break;
				case 'teacher':
					$id_teacher = $r['id_teacher'];
					$teacher = $r['teacher'];
					DB::$mysqli->query("DELETE FROM teachers WHERE id_teacher='$id_teacher'");
					$s = 'Данные преподавателя <b>'.$teacher.' ('.$id_teacher.')</b> удалены из справочника <b>преподаватели</b> (teachers)';
				break;
				case 'subject':
					$id_subject = $r['id_subject'];
					$subject = $r['subject'];
					DB::$mysqli->query("DELETE FROM subjects WHERE id_subject='$id_subject'");
					$s = 'Данные дисциплины <b>'.$subject.' ('.$id_subject.')</b> удалены из справочника <b>дисциплины</b> (subjects)';
				break;
			}
		break;			
	}	
	mes($s);
	exit(json_encode($s));
}

function db($type,$s){           // Проверка и преобразование поля по структуру таблицы БД
	$a = explode('(',$type);
	switch ($a[0]){
		case 'date': $s = d_db($s); break;
		case 'tinyint': $s = (int)($s); break; 
		case 'smallint': $s = (int)($s); break; 
		case 'double': $s = (double)($s); break; 
		case 'decimal': $s = (double)($s); break; 
		case 'numeric': $s = (double)($s); break; 
		case 'float': $s = (double)($s); break; 
	}
	return $s;
}
function d_db($d){               // Перевод даты в формат БД
	if ($d != ''){
		$year = substr($d,6,4);
		if (strlen($year)<4){$year = '20'.$year;}
		$d = $year.'-'.substr($d,3,2).'-'.substr($d,0,2);
	} else {$d = '2000-01-01';}
	return $d;
}
function db_d($d){               // Перевод даты из формата БД в обычный
	if ($d == '' || $d == '0000-00-00'){$d = '';}
		else {$d = substr($d,8,2).'.'.substr($d,5,2).'.'.substr($d,0,4);} 
	return $d;
}
function colexcel($col){         // Определение колонки по номеру
	$st='';
	$a=intval($col/26);
	if ($a){$st=$st.chr(64+$a);}
	$b=$col%26;
	$st=$st.chr(65+$b);
	return ($st);
}
function u($a,$m){               // Форматирование числа без нулей в конце
	$a = +$a; if (abs($a) < 0.0000001) return(''); 
	if (!$m) $m = 0; $m = +$m;
	$r = number_format($a,$m,'.','');
	$j = 0;
	while(($r[strlen($r)-1] == '0' OR $r[strlen($r)-1] == '.') AND strpos($r,'.') > 0 AND $j < 3){++$j; $r = substr($r, 0, -1);}
	return($r);
}
function u_($a,$m){              // Форматирование числа
	if (!is_numeric($a)) $a = 0;
	$a = +$a; if (abs($a) < 0.0000001) return(''); 
	if (!$m) $m = 0; $m = +$m;
	$r = number_format($a,$m,'.','');
	return($r);
}
?>