<?php # Библиотека php-функций авторизации и регистрации
	require_once('lib.php');
	$att = attemptsGet($ip,4,180);
	if ($att[0] > 555) mes('Вы меняете данные уже более 10-ти раз...<br>Так подождите теперь '.date('i:s',$att[1]).'</b> и меняйте дальше!');
	$USER = $_POST['USER'];
	// чтение логина и пароля ********************
	if ($USER['login'] == '' AND $USER['pass'] == ''){$USER['login'] = $_COOKIE['login']; $USER['pass'] = $_COOKIE['pass'];}
	$func = $_POST['func'];
	$err = [];
	if ($func == 'Admin'){$u = access(); if ($u['id']!='1'&&$u['id']!='123') mes('Нельзя так');}	
	if ($func != 'readPaint'){ 
		if ($e=validate_login($USER['login'])) $err[] = $e;
		if ($func != 'readLogin'){ 
			if (($func != 'CheckIn')&&($func != 'Admin')){if ($e=validate_password($USER['pass'])) $err[] = $e;}
			if ($USER['pass_new'] != ''){if ($e=validate_password($USER['pass_new'])) $err[] = $e;} else $USER['pass_new'] = $USER['pass'];
			if ($USER['username'] != ''){if ($e=validate_username($USER['username'])) $err[] = $e;}
			if ($USER['phone'] != ''){if ($e=validate_phone($USER['phone'])) $err[] = $e;}
			if ($USER['email'] != ''){if ($e=validate_email($USER['email'])) $err[] = $e;}
			if ($USER['note'] != ''){if ($e=validate_note($USER['note'])) $err[] = $e;}
		}	
		if (count($err) != 0){$s = ''; foreach($err as $i => $se) $s = $s.++$i.'. '.$se.'<br>';	mes($s);}
	}
	switch ($func){
		case 'readLogin': readLogin($USER); break;
		case 'Login': Login($USER); break;
		case 'CheckIn': CheckIn($USER); break;
		case 'Account': Account($USER); break;
		case 'Admin': Admin($USER); break;
		case 'readPaint': readPaint(); break;
		case 'writePaint': writePaint(); break;
	}
function readLogin($USER){      # Чтение данных пользователя по логину 
	$login = $USER['login'];
	$search = 'id_user,login,username,email,phone,note,own,access';
	$res = DB::$mysqli->query("SELECT $search FROM users WHERE login='$login'");
	$row = $res->fetch_row();
	$USER = array();
	if ($row[0]){
		$arr = explode(',',$search);
		$length=count($row);
		for ($i=0; $i<$length; $i++) $USER[$arr[$i]] = $row[$i];
		exit(json_encode($USER));
	} else mes('Пользователь с логином: <b>'.$login.'</b> не зарегистрирован!');
}
function readPaint(){           # Чтение paint 
	$paint = [];
	$paint['bc'] = $_COOKIE['bc'];
	$paint['c'] = $_COOKIE['c'];
	$paint['bc1'] = $_COOKIE['bc1'];
	$paint['c1'] = $_COOKIE['c1'];
	exit(json_encode($paint));
}
function writePaint(){          # Проверка логина + пароля 
	$tm = 7*24*60*60;
	$paint = $_POST['paint'];
	setcookie('bc',$paint['bc'],time()+$tm);
	setcookie('c',$paint['c'],time()+$tm);
	setcookie('bc1',$paint['bc1'],time()+$tm);
	setcookie('c1',$paint['c1'],time()+$tm);
	exit(json_encode($tm));
}
function Login($USER){          # Проверка логина + пароля 
	$ip = get_ip();
	$login = $USER['login'];
	$password = $USER['pass'];
	$pas = md5(strrev(md5($password)));
	$search = 'id_user,login,username,email,phone,note,own,access';
	$res = DB::$mysqli->query("SELECT $search FROM users WHERE login='$login' AND password='$pas'");
	$row = $res->fetch_row();
	$USER = array();
	if ($row[0]){
		$arr = explode(',',$search);
		$length=count($row);
		for ($i=0; $i<$length; $i++) $USER[$arr[$i]] = $row[$i];
		$USER['bc'] = $_COOKIE['bcolor']; $USER['c'] = $_COOKIE['color'];
		$hash = md5($login.$ip.mt_rand());
		DB::$mysqli->query("UPDATE users SET hash='$hash' WHERE login='$login'");
		$tm = 7*24*60*60;
		// сохранение логина и пароля ***********************************
		$keeplogin = 'on'; if (isset($keeplogin) AND $keeplogin == 'on'){setcookie('login', $login, time()+$tm); setcookie('pass', $password, time()+$tm);}
		setcookie('hash', $hash, time()+$tm);
		session_name($hash);
		session_start();
		$_SESSION['id']=$USER['id_user'];
		$_SESSION['login']=$USER['login'];
		$_SESSION['access']=$USER['access'];
		exit(json_encode($USER));
	} else mes('Пользователь с логином: <b>'.$login.'</b> и паролем: <b>'.$password.'</b> не зарегистрирован!');
}
function CheckIn($USER){        # Регистрация пользователя
	$login = $USER['login'];
	$username = $USER['username'];
	$phone = $USER['phone'];
	$email = $USER['email'];
	$note = $USER['note'];
	$res = DB::$mysqli->query("SELECT COUNT(*) FROM users WHERE login='$login'");
	$row = $res->fetch_row();
	if ($row[0]) mes("Пользователь c логином ($login) уже зарегистрирован.<br>Если это Ваша учётная запись и Вы забыли пароль - обратитесь к администратору.");
	$res = DB::$mysqli->query("SELECT COUNT(*) FROM users WHERE email='$email' AND email");
	$row = $res->fetch_row();
	if ($row[0]) mes('Пользователь с введённым e-mail <b>'.$email.'</b> уже зарегистрирован.<br>Если это Ваш e-mail - обратитесь к администратору.');
	$password = '12345';
	$pas = md5(strrev(md5($password)));
	$res = DB::$mysqli->query ("INSERT INTO users (login,password,username,email,phone,note,access,date)
		VALUES('$login','$pas','$username','$email','$phone','$note','0',NOW())");
	if ($res != 'TRUE') mes('Ошибка, регистрация не прошла...<br>Обратитесь - обратитесь к администратору.');
	exit(json_encode('Вы зарегистрированы, Ваш логин - <b>'.$login.'</b><br>Пароль для входа: <b>12345</b>
		<br>Перейдите на вкладку <b>Вход</b> и авторизуйтесь.
		<br>Не забудьте сменить этот пароль на более защищенный: для этого
		<br>можно вернуться в окно пользователя (кнопка справа вверху после имени),
		<br>затем вкладка "<b>Данные</b>"
		<br>Теперь обратитесь к <b>администраторам</b> (см.вкладку <b>Контакты</b>), чтобы Вам дали <b>права доступа</b><br>'));
}
function Account($USER){        # Изменение данных аккаунта
	$login = $USER['login'];
	$username = $USER['username'];
	$phone = $USER['phone'];
	$email = $USER['email'];
	if ($email != ''){
		$res = DB::$mysqli->query("SELECT COUNT(*) FROM users WHERE email='$email' AND login!='$login' AND login");
		$row = $res->fetch_row();
		if ($row[0]) mes('Данный e-mail занят другим пользователем.');
	}	
	$note = $USER['note'];
	$pas = md5(strrev(md5($USER['pass'])));
	$res = DB::$mysqli->query("SELECT COUNT(*) FROM users WHERE login='$login' AND password='$pas'");
	$row = $res->fetch_row();
	if ($row[0]){
		$pas = md5(strrev(md5($USER['pass_new'])));
		$res = DB::$mysqli->query("UPDATE users SET password='$pas',username='$username',phone='$phone',email='$email',note='$note' WHERE login='$login'");
		if ($res) exit(json_encode('Измененные данные с логином <b>'.$USER['login'].'</b> внесены в БД.<br>Войдите в систему с паролем: <b>'.$USER['pass_new'].'</b>!'));
			else mes('Ошибка при внесении данных с логином <b>'.$USER['login'].'</b> в БД!');
	} else mes('Пароль <b>'.$USER['pass'].'</b> не соответствует логину <b>'.$USER['login'].'</b>!');
}
function Admin($USER){          # Изменение данных аккаунта
	$login = $USER['login'];
	$res = DB::$mysqli->query("SELECT * FROM users WHERE login='$login'");
	if (!$res) mes('Пользователь с логином: <b>'.$login.'</b> не зарегистрирован!');
	$username = $USER['username'];
	$phone = $USER['phone'];
	$email = $USER['email'];
	if ($email != ''){
		$res = DB::$mysqli->query("SELECT COUNT(*) FROM users WHERE email='$email' AND login!='$login' AND login");
		$row = $res->fetch_row();
		if ($row[0]) mes('Данный e-mail занят другим пользователем.');
	}	
	$note = $USER['note'];
	$access = $USER['access'];
	$own = $USER['own'];
	$pass_new = $USER['pass_new'];
	$res = DB::$mysqli->query("UPDATE users SET username='$username',phone='$phone',email='$email',note='$note',access='$access',own='$own' WHERE login='$login'");
	if ($pass_new != ''){
		$pas = md5(strrev(md5($USER['pass_new'])));
		$res = DB::$mysqli->query("UPDATE users SET password='$pas' WHERE login='$login'");
	}
	if ($res) exit(json_encode('Измененные данные с логином <b>'.$USER['login'].'</b> внесены в БД.'));
		else mes('Ошибка при внесении данных с логином <b>'.$USER['login'].'</b> в БД!');
}
function num_($s){$r = ''; for ($i = 0; $i < strlen($s); ++$i){if (is_numeric($s[$i])){$r = $r.$s[$i];}} return $r;}
function validate_login($s){if (!preg_match('/^[a-zа-рс-яё0-9_]{3,40}$/i',$s)){      # mysql_real_escape_string($s)
	return 'Логин <b>'.$s.'</b>(L=<b>'.strlen($s).'</b>) должен содержать от 3-х до 20-ти <b>букв</b> и/или <b>цифр</b>';}
	else {return false;}}
function validate_password($s){if (!preg_match('/^[a-zа-рс-яё0-9_]{3,48}$/i',$s)){
	return 'Пароль <b>'.$s.'</b> (L=<b>'.strlen($s).'</b>) должен содержать от 8-ми до 24-х <b>букв</b> и/или <b>цифр</b>';}
	else {return false;}}
function validate_username($s){if (!preg_match('/^[a-zа-рс-яё0-9_ )(:;.,!?=+-]{1,200}$/i',$s)){
	return 'Имя <b>'.$s.'</b>(L=<b>'.strlen($s).'</b>) должно содержать не более 99-ти <b>букв</b>, пробелов и знаков препинания';}
	else {return false;}}
function validate_phone($s){if (!preg_match('/^[0-9_ )(+-]{11,25}$/',$s) OR (strlen(num_($s)) != 11))
	{return 'Номер телефона введите в формате <b>x(xxx)xxx-xx-xx</b>';}
	else {return false;}}
function validate_email($s){if (!preg_match('/^[a-z0-9_\.\-]+@([a-z0-9\-]+\.)+[a-z]{2,4}$/i',$s)){
	return 'Адрес электронной почты введите в формате <b>name@domain.ru</b>';}
	else {return false;}}
function validate_note($s){if (!preg_match('/^[a-zа-рс-яё0-9_ )(\":;.,!?=+-]{1,500}$/i',$s)){
	return 'В текстовом поле (<i>Примечание</i>) <b> должно быть от <b>1</b>-го до <b>250</b>-ти разрешенных символов';}
	else {return false;}}
function validate_captcha($s){if ($s != 'gvz88'){return 'Символы с картинки введены неверно';}
	else {return false;}}
?>